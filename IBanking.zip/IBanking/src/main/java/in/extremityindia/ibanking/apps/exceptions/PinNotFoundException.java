package in.extremityindia.ibanking.apps.exceptions;

public class PinNotFoundException extends Exception{
	
	public PinNotFoundException(String msg) {
		super(msg);
	}

}
