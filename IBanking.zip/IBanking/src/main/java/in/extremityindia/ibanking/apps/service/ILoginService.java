package in.extremityindia.ibanking.apps.service;

import in.extremityindia.ibanking.apps.beans.User;

import java.util.List;

public interface ILoginService {
		public List<User> loginCheck(User user);
}
