package in.extremityindia.ibanking.apps.controllers;

import in.extremityindia.ibanking.apps.beans.User;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;





@Controller
public class CommonController {

	@RequestMapping(value = "/index", method = RequestMethod.GET)
	public ModelAndView WelcomePage(Model model) {
		return new ModelAndView("globalHome", "user", new User());
	}
	
	
	/*---------------------------Mapping For Customer------------------------------------*/
	@RequestMapping(value = "/profile", method = RequestMethod.GET)
	public ModelAndView perofile(Model model) {
		return new ModelAndView("profilemenu");
	}
	
	@RequestMapping(value = "/myaccounts", method = RequestMethod.GET)
	public ModelAndView myaccounts(Model model) {
		return new ModelAndView("myAccountsmenu");
	}
	
	
	@RequestMapping(value = "/payment_transfer", method = RequestMethod.GET)
	public ModelAndView payment_transfer(Model model) {
		return new ModelAndView("payment_transfermenu");
	}
	
	
	@RequestMapping(value = "/e_service", method = RequestMethod.GET)
	public ModelAndView e_service(Model model) {
		return new ModelAndView("e-servicesmenu");
	}

	/*---------------------------Mapping For Customer------------------------------------*/
	
	
	/*---------------------------Mapping For Admin------------------------------------*/
	
	@RequestMapping(value = "/customer", method = RequestMethod.GET)
	public ModelAndView customer(Model model) {
		System.out.println("IN CUSTOMER CONTROLLER");
		return new ModelAndView("customermenu");
	}
	
	@RequestMapping(value = "/report", method = RequestMethod.GET)
	public ModelAndView report(Model model) {
		System.out.println("IN REPORT CONTROLLER");
		return new ModelAndView("reportmenu");
	}
	
	/*---------------------------Mapping For Admin------------------------------------*/
}
