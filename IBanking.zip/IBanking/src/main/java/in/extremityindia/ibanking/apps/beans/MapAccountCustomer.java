package in.extremityindia.ibanking.apps.beans;

import java.io.Serializable;
import javax.persistence.*;


/**
 * The persistent class for the map_account_customer database table.
 * 
 */
@Entity
@Table(name="map_account_customer")
@NamedQuery(name="MapAccountCustomer.findAll", query="SELECT m FROM MapAccountCustomer m")
public class MapAccountCustomer implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="map_id")
	private int mapId;

	//bi-directional many-to-one association to Account
	@ManyToOne
	@JoinColumn(name="account_id")
	private Account account;

	//bi-directional many-to-one association to Customer
	@ManyToOne
	@JoinColumn(name="customer_id")
	private Customer customer;

	public MapAccountCustomer() {
	}

	public int getMapId() {
		return this.mapId;
	}

	public void setMapId(int mapId) {
		this.mapId = mapId;
	}

	public Account getAccount() {
		return this.account;
	}

	public void setAccount(Account account) {
		this.account = account;
	}

	public Customer getCustomer() {
		return this.customer;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}

}