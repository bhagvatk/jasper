package in.extremityindia.ibanking.apps.daoimpl;

import in.extremityindia.ibanking.apps.beans.User;
import in.extremityindia.ibanking.apps.dao.ILoginDao;
import java.util.List;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;

public class LoginDaoImpl implements ILoginDao {

	@Autowired
	private SessionFactory hibernateSessionFactory;

	public void setSessionFactory(SessionFactory sf) {
		this.hibernateSessionFactory = sf;
	}

	@SuppressWarnings("unchecked")
	public List<User> loginCheck(User user) {
		List<User> loginList = null;
		Session session = hibernateSessionFactory.openSession();
		System.out.println("login dao");
		String status = "Active";
		/*
		 * try { password =
		 * PasswordEncrptionHelper.isValidLogin(login.getPassword()); } catch
		 * (Exception e) { e.printStackTrace(); }
		 */
		
		 loginList = session.createQuery( "from User where uname='" +
		 user.getUname() + "' and pass='" + user.getPass() + "' and status='"
		 + status + "'") .list();
		 
		System.out.println(loginList);
		return loginList;
	}

}
