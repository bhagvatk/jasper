package in.extremityindia.ibanking.apps.exceptions;

public class TransactionAbortedException extends Exception {

	/**
	 * @author Rahul Moundekar
	 */
	private static final long serialVersionUID = 1L;

	public TransactionAbortedException(String msg) {
		super(msg);
	}

}
