package in.extremityindia.ibanking.apps.daoimpl;

import java.util.List;
import org.hibernate.Criteria;
import org.hibernate.FetchMode;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import in.extremityindia.ibanking.apps.beans.Account;
import in.extremityindia.ibanking.apps.dao.IApprovalDao;

public class ApprovalDaoImpl implements IApprovalDao {

	@Autowired
	private SessionFactory hibernateSessionFactory;

	public void setSessionFactory(SessionFactory sf) {
		this.hibernateSessionFactory = sf;
	}
	String status = "Approved";
	
	@SuppressWarnings("unchecked")
	@Override
	public List<Account> getATMStatusPending() {
		List<Account> atmAccounts = null;
		try {
			Session session = hibernateSessionFactory.openSession();

			Criteria cr = session.createCriteria(Account.class).add(
					Restrictions.eq("atmStatus", "Pending"));
			cr.setFetchMode("customer", FetchMode.SELECT);
			atmAccounts = cr.list();
			System.out.println("atm List : " + atmAccounts);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return atmAccounts;
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<Account> getDebitStatusPending() {
		List<Account> debitAccounts = null;
		try {
			Session session = hibernateSessionFactory.openSession();
			Criteria cr = session.createCriteria(Account.class).add(
					Restrictions.eq("debitStatus", "Pending"));
			cr.setFetchMode("customer", FetchMode.SELECT);
			debitAccounts = cr.list();
			System.out.println("debitAccounts List : " + debitAccounts);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return debitAccounts;
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<Account> getCreditStatusPending() {
		List<Account> creditAccounts = null;
		try {
			Session session = hibernateSessionFactory.openSession();
			Criteria cr = session.createCriteria(Account.class).add(
					Restrictions.eq("creditStatus", "Pending"));
			cr.setFetchMode("customer", FetchMode.SELECT);
			creditAccounts = cr.list();
			System.out.println("creditStatus List : " + creditAccounts);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return creditAccounts;
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<Account> getCheckBookStatusPending() {
		List<Account> checkBookAccounts = null;
		try {
			Session session = hibernateSessionFactory.openSession();
			Criteria cr = session.createCriteria(Account.class).add(
					Restrictions.eq("checkbookStatus", "Pending"));
			cr.setFetchMode("customer", FetchMode.SELECT);
			checkBookAccounts = cr.list();
			System.out.println("checkBookAccounts List : " + checkBookAccounts);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return checkBookAccounts;
	}

	@Override
	public void setATMStatusApprove(Integer accountId) {
		try {
			Session session = hibernateSessionFactory.openSession();
			SQLQuery query = session
					.createSQLQuery("update account a set a.atm_status=? where a.account_id="
							+ accountId);
			query.setParameter(0, status);
			query.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}

	@Override
	public void setDebitStatusApprove(Integer accountId) {
		try {
			Session session = hibernateSessionFactory.openSession();
			SQLQuery query = session
					.createSQLQuery("update account a set a.debit_status=? where a.account_id="
							+ accountId);
			query.setParameter(0, status);
			query.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Override
	public void setCredittatusApprove(Integer accountId) {
		try {
			Session session = hibernateSessionFactory.openSession();
			SQLQuery query = session
					.createSQLQuery("update account a set a.credit_status=? where a.account_id="
							+ accountId);
			query.setParameter(0, status);
			query.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Override
	public void setCheckBookStatusApprove(Integer accountId) {
		try {
			Session session = hibernateSessionFactory.openSession();
			SQLQuery query = session
					.createSQLQuery("update account a set a.checkbook_status=? where a.account_id="
							+ accountId);
			query.setParameter(0, status);
			query.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

}
