$(function() {
$("#withdraw").click(function() {
	 $('#apply').prop('disabled', 'disabled');
	$("#withdrawhide").show();
	 $("#depositehide").hide();
	 $("#transferhide").hide();
	 $("#body").hide();
});
$("#deposite").click(function() {
	 $( "#depositehide" ).show();
	 $('#apply').prop('disabled', 'disabled');
	 $("#withdrawhide").hide();
	 $("#body").hide();
	 $("#transferhide").hide();
});
$("#QuickLinks").click(function() {
	 $( "#body" ).show();
	 
	 $("#withdrawhide").hide();
	 $("#depositehide").hide();
	 $("#transferhide").hide();
});
$("#transfer").click(function() 
{
	$( "#transferhide" ).show();
	 $( "#depositehide" ).hide();
	 $("#withdrawhide").hide();
	 $("#body").hide();
		
});
	$("#apply").click(function() {
		 $( "#depositehide" ).show();
		 $("#withdrawhide").hide();
		 $("#body").hide();
		 $("#transferhide").hide();
	});

$("#withdrawhide").hide();
$("#depositehide").hide();
$("#transferhide").hide();

});