package in.extremityindia.ibanking.apps.beans;

import java.io.Serializable;
import javax.persistence.*;
import java.util.Set;


/**
 * The persistent class for the location database table.
 * 
 */
@Entity
@NamedQuery(name="Location.findAll", query="SELECT l FROM Location l")
public class Location implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="loc_id")
	private int locId;

	@Column(name="loc_name")
	private String locName;

	//bi-directional many-to-one association to BankBranch
	@OneToMany(mappedBy="location")
	private Set<BankBranch> bankBranches;

	//bi-directional many-to-one association to City
	@ManyToOne
	@JoinColumn(name="city_id")
	private City city;

	public Location() {
	}

	public int getLocId() {
		return this.locId;
	}

	public void setLocId(int locId) {
		this.locId = locId;
	}

	public String getLocName() {
		return this.locName;
	}

	public void setLocName(String locName) {
		this.locName = locName;
	}

	public Set<BankBranch> getBankBranches() {
		return this.bankBranches;
	}

	public void setBankBranches(Set<BankBranch> bankBranches) {
		this.bankBranches = bankBranches;
	}

	public BankBranch addBankBranch(BankBranch bankBranch) {
		getBankBranches().add(bankBranch);
		bankBranch.setLocation(this);

		return bankBranch;
	}

	public BankBranch removeBankBranch(BankBranch bankBranch) {
		getBankBranches().remove(bankBranch);
		bankBranch.setLocation(null);

		return bankBranch;
	}

	public City getCity() {
		return this.city;
	}

	public void setCity(City city) {
		this.city = city;
	}

}