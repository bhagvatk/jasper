package in.extremityindia.ibanking.apps.controllers;

import java.util.*;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import in.extremityindia.ibanking.apps.beans.MapAccountCustomer;
import in.extremityindia.ibanking.apps.beans.Transaction;
import in.extremityindia.ibanking.apps.beans.User;
import in.extremityindia.ibanking.apps.service.IMyAccountService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class MyAccountController {
	
	@Autowired
	IMyAccountService iMyAccountService;
	Integer accId;
	
	@RequestMapping(value="/getMiniStatementDetails" ,method={ RequestMethod.GET,RequestMethod.POST } )
	public @ResponseBody List<Transaction> getMiniStatement(@ModelAttribute User user,HttpServletRequest request){
		System.out.println("IN MYACCOUNT CONTROLLER");
		System.out.println("IN GET MINI STATEMENT METHOD");
		  HttpSession session=request.getSession(); 
		  User u=(User)session.getAttribute("user");
		  Set map=u.getCustomer().getMapAccountCustomers();
		  Iterator itr=map.iterator();
		  while(itr.hasNext()){
			  MapAccountCustomer mapAc=(MapAccountCustomer)itr.next();
			  accId=mapAc.getAccount().getAccountId();
		  }
		  
		List<Transaction> transactionDetail=iMyAccountService.getMiniStatement(accId);
		List<Transaction> tail = transactionDetail.subList(Math.max(transactionDetail.size() - 10, 0), transactionDetail.size());
		System.out.println("transactionDetail:"+tail);
		return tail;
	}
	
	@RequestMapping(value="/getTransactionDetails" ,method={ RequestMethod.GET,RequestMethod.POST } )
	public @ResponseBody List<Transaction> getTransactionDetail(@ModelAttribute User user,HttpServletRequest request){
		System.out.println("IN MYACCOUNT CONTROLLER");
		System.out.println("IN GET TRANSACTION DETAIL METHOD");
		  HttpSession session=request.getSession(); 
		  User u=(User)session.getAttribute("user");
		  Set map=u.getCustomer().getMapAccountCustomers();
		  Iterator itr=map.iterator();
		  while(itr.hasNext()){
			  MapAccountCustomer mapAc=(MapAccountCustomer)itr.next();
			  accId=mapAc.getAccount().getAccountId();
		  }
		  
		List<Transaction> transactionDetail=iMyAccountService.getMiniStatement(accId);
		System.out.println("transactionDetail:"+transactionDetail);
		return transactionDetail;
	}
}
