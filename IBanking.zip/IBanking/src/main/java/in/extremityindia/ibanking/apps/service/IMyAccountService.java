package in.extremityindia.ibanking.apps.service;
import in.extremityindia.ibanking.apps.beans.*;
import java.util.*;

public interface IMyAccountService {
	public List<Transaction> getMiniStatement(Integer accountid);
}
