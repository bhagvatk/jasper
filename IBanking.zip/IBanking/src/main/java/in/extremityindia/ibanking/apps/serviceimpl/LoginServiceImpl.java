package in.extremityindia.ibanking.apps.serviceimpl;

import in.extremityindia.ibanking.apps.beans.User;
import in.extremityindia.ibanking.apps.dao.ILoginDao;
import in.extremityindia.ibanking.apps.service.ILoginService;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;

public class LoginServiceImpl implements ILoginService {

	@Autowired
	ILoginDao iLoginDao;

	public List<User> loginCheck(User user) {
		return iLoginDao.loginCheck(user);
	}

}
