package in.extremityindia.ibanking.apps.serviceimpl;

import org.springframework.beans.factory.annotation.Autowired;

import in.extremityindia.ibanking.apps.dao.IEServicesDao;
import in.extremityindia.ibanking.apps.service.IEServicesService;

public class EServicesServiceImpl implements IEServicesService{
	
	@Autowired
	IEServicesDao iEServicesDao;

	@Override
	public void submitATMService(Integer acno) {
		iEServicesDao.submitATMDao(acno);
		
	}

	@Override
	public void submitDebitService(Integer acno) {
		iEServicesDao.submitDebitDao(acno);
		
	}

	@Override
	public void submitCreditService(Integer acno,String emp_type) {
		iEServicesDao.submitCreditDao(acno,emp_type);
		
	}

	@Override
	public void submitCheckbookService(Integer acno, Integer no_of_leaves) {
		iEServicesDao.submitCheckbookDao(acno,no_of_leaves);
		
	}

}
