package in.extremityindia.ibanking.apps.exceptions;

public class BelowMinimumBalanceException extends ExceedLimitException {

	/**
	 * @author Rahul Moundekar
	 */
	private static final long serialVersionUID = 1L;

	public BelowMinimumBalanceException(String msg) {
		super(msg);
	}
}
