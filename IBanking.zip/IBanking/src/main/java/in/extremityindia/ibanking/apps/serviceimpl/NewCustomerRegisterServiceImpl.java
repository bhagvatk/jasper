package in.extremityindia.ibanking.apps.serviceimpl;

import in.extremityindia.ibanking.apps.beans.Account;
import in.extremityindia.ibanking.apps.beans.BankBranch;
import in.extremityindia.ibanking.apps.beans.City;
import in.extremityindia.ibanking.apps.beans.Location;
import in.extremityindia.ibanking.apps.beans.State;
import in.extremityindia.ibanking.apps.dao.INewCustomerRegistrationDao;
import in.extremityindia.ibanking.apps.helpers.AccountCreationHelper;
import in.extremityindia.ibanking.apps.service.INewCustomerRegisterService;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;



public class NewCustomerRegisterServiceImpl implements INewCustomerRegisterService


{
	/**
	 * @ TANVEER BOBADE
	 */
	
	@Autowired
	INewCustomerRegistrationDao newCustomerRegistrationDao ;

	public long	LAST_ACCOUNT_NUMBER;
	public long NEW_ACCOUNT_NUMBER;
	public Integer PIN_NUMBER;
	
	@Override
	public List<State> getStateListService() {
		System.out.println("In service");
		return newCustomerRegistrationDao.getStateListDao() ;
	}


	@Override
	public List<City> getCityListService(String sid) {
		
		return newCustomerRegistrationDao.getCityListDao(sid);
	}


	@Override
	public List<Location> getLocationListService(String cid) {
		
		return newCustomerRegistrationDao.getLocationListDao(cid);
	}


	@Override
	public List<BankBranch> getBankBranchListService(String lid) {
		
		return  newCustomerRegistrationDao.getBankBranchListDao(lid);
	}

	@Override
	public List<BankBranch> getIFSCCodeListService(String lid) {
	
		return newCustomerRegistrationDao.getIFSCCodeListDao(lid);
	}

	

	
	@Override
	public void setCustomerInformationService(String firstname,
			String lastname, String gender, String dob, String aod,
			String address, String state, String city, String acctype,
			String location, String branch, String ifsccode,String mobilenumber,String emailid,String amount){
	
		LAST_ACCOUNT_NUMBER=newCustomerRegistrationDao.checkAccountNumberDao();
		NEW_ACCOUNT_NUMBER=AccountCreationHelper.accountNumber(LAST_ACCOUNT_NUMBER);
		System.out.println("New Acount Number"+	NEW_ACCOUNT_NUMBER);
		try {
			PIN_NUMBER=AccountCreationHelper.generatePin();
			System.out.println("Genrated Pin"+PIN_NUMBER);
		} catch (Exception e) {
			
			e.printStackTrace();
		}
		newCustomerRegistrationDao.setAllCustomerInformationDao(firstname, lastname, gender, dob, aod, address, state, city, acctype, location, branch, ifsccode,NEW_ACCOUNT_NUMBER,PIN_NUMBER,mobilenumber,emailid,amount);
	}


	@Override
	public String checkEmailService(String emailid) {
		
		return newCustomerRegistrationDao.checkEmailDao(emailid);
	}


	@Override
	public String checkMobileService(String mobilenumber) {
		
		return newCustomerRegistrationDao.checkMobileDao(mobilenumber);
	}
}
