package in.extremityindia.ibanking.apps.utility;

public class Constants {

	public static final String ADMIN = "admin";

	public static final String CUSTOMER = "customer";


}
