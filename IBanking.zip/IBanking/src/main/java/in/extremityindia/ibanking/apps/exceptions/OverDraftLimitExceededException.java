package in.extremityindia.ibanking.apps.exceptions;

public class OverDraftLimitExceededException extends ExceedLimitException {

	/**
	 * @author Rahul Moundekar
	 */
	private static final long serialVersionUID = 1L;

	public OverDraftLimitExceededException(String msg) {
		super(msg);
	}
}
