package in.extremityindia.ibanking.apps.controllers;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import in.extremityindia.ibanking.apps.beans.BankBranch;
import in.extremityindia.ibanking.apps.beans.City;
import in.extremityindia.ibanking.apps.beans.Location;
import in.extremityindia.ibanking.apps.beans.State;
import in.extremityindia.ibanking.apps.service.IBranchService;
import in.extremityindia.ibanking.apps.service.INewCustomerRegisterService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class BranchController {

	@Autowired
	IBranchService iBranchService;
	@Autowired
	INewCustomerRegisterService newCustomerRegisterService;	
	//We have used same code of dropdown which we have already used for New Cutomer Registration
	
	
	
	@RequestMapping(value = "/branch", method = { RequestMethod.GET,
			RequestMethod.POST })
	public ModelAndView getBranchesList() {
		List<BankBranch> branchList = iBranchService.getBranchList();
		List<State> stateList=newCustomerRegisterService.getStateListService();
			
	
		
		Map branchAndStateList=new HashMap();
		branchAndStateList.put(1,stateList);
		branchAndStateList.put(2,branchList);
		if (branchList.isEmpty()||stateList.isEmpty()) 
		{
			String error = "No Any Branches";
		
			return new ModelAndView("branchmenu", "error", error);
		} else {
			return new ModelAndView("branchmenu", "branchAndStateList", branchAndStateList);
		}
	}
	@RequestMapping(value = "/selectCitiesB", method = { RequestMethod.GET,
			RequestMethod.POST })
	public @ResponseBody  void cityListResponse(@RequestParam String state_id,HttpServletRequest request,HttpServletResponse response) throws IOException {
		
		String sid=state_id;
		
		List<City> cityList=newCustomerRegisterService.getCityListService(sid);
		PrintWriter pw = response.getWriter();
		pw.write("<option>--Select City--</option>");
		Iterator<City> itr = cityList.iterator();
		while (itr.hasNext()) {
			City city = (City) itr.next();
			pw.write("<option value=" + city.getCityId()+ ">"
					+ city.getCityName().toUpperCase() + "</option>");
		}
	}
	@RequestMapping(value = "/selectLocationB", method = { RequestMethod.GET,
			RequestMethod.POST })
	public @ResponseBody  void locationListResponse(@RequestParam String city_id,HttpServletRequest request,HttpServletResponse response) throws IOException {
		
		String cid=city_id;
		System.out.println("city ID"+cid);
		System.out.println("In Registration Controller");
		List<Location> cityList=newCustomerRegisterService.getLocationListService(cid);
		PrintWriter pw = response.getWriter();
		pw.write("<option>--Select Location--</option>");
		Iterator<Location> itr = cityList.iterator();
		while (itr.hasNext()) {
			Location loc = (Location)itr.next();
			pw.write("<option value=" + loc.getLocId()+ ">"
					+ loc.getLocName().toUpperCase() + "</option>");
		}
	}
	@RequestMapping(value = "/addbranch", method = { RequestMethod.GET,
			RequestMethod.POST })
	public String addNewBranch(@ModelAttribute BankBranch bankBranch) {
		iBranchService.insertBranches(bankBranch);
		return "redirect:/branch.htm";
	}

}
