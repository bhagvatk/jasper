package in.extremityindia.ibanking.apps.daoimpl;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import in.extremityindia.ibanking.apps.beans.Customer;
import in.extremityindia.ibanking.apps.beans.User;
import in.extremityindia.ibanking.apps.dao.IProfileDao;

public class ProfileDaoImpl implements IProfileDao{
	@Autowired
	private SessionFactory hibernateSessionFactory;

	public void setSessionFactory(SessionFactory sf) {
		this.hibernateSessionFactory = sf;
	}

	@Override
	public int profileupadate(Customer customer) {
		int flag=0;
		try {
			Session session = hibernateSessionFactory.openSession();	
	//		session.saveOrUpdate(customer);
			Transaction tx=session.beginTransaction();
	//Query i = session.createQuery("update customer set nric="+customer.getNric()+",fname="+customer.getFname()+",lname="+customer.getLname()+",address="+customer.getAddress()+",gender="+customer.getGender()+",nationality="+customer.getNationality()+",date_of_birth="+customer.getDateOfBirth()+",date_of_join="+customer.getDateOfJoin()+" where customer_id="+customer.getCustomerId());
			//customer=(Customer) session.load(Customer.class,customer.getCustomerId());
			session.merge(customer);
			tx.commit();
			System.out.println("Successfull");			
			flag=1;			
		} catch (Exception e) {
			flag=0;
		}
				System.out.println("in profile daoimpl+++++++++++++");
		//(nric,fname,lname,address,gender,nationality,date_of-birth,date_of_join)where customer_id="+customer.getCustomerId());
		//update customer c set c.nric="+customer.getNric()+",c.fname="+customer.getFname()+",c.lname="+customer.getLname()+",c.address="+customer.getAddress()+",c.gender="+customer.getGender()+",c.nationality="+customer.getNationality()+",c.date_of_birth="+customer.getDateOfBirth()+",c.date_of_join="+customer.getDateOfJoin()+" where c.customer_id="+customer.getCustomerId());
		return flag;
	}

	
	public int profilechangepassword(User user){
	 int flag =0;
	  int rowCount=0;
	 try{
		Session session=hibernateSessionFactory.openSession();
		//User user2=(User) session.load(User.class,user.getUId());
		//session.update(user2);
		//session.merge(user);
		
		
		 String sql = "update user u set pass = ? where u.uId ="+ user.getUId();
	     Query query= session.createSQLQuery(sql);
	     
	     System.out.println("user.getPass()--------------"+user.getPass());
	     query.setParameter(0,user.getPass());
	     rowCount= query.executeUpdate();
		/*Transaction t=session.beginTransaction();
		t.commit();
*/		System.out.println("password change successfull");
	session.clear();
		 }
		 catch(Exception e)
		 {
			 e.printStackTrace();
		 }
	 
	 	 
	return rowCount;
		
}
	
}