package in.extremityindia.ibanking.apps.helpers;

import java.math.BigInteger;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

public class PasswordEncrptionHelper {
	
	
	public synchronized static String isValidLogin(String password) {
		String password1=null;
		try {
			password1=MD5(SHA1(password));
		} catch (NoSuchAlgorithmException e) {
			e.printStackTrace();
		} 
		
		return password1;
	}

	public static synchronized String encryptPassword(String rawPassword) {
		try {
			return MD5(SHA1(rawPassword));
		} catch (NoSuchAlgorithmException e) {
			e.printStackTrace();
		}
		return null;
	}

	private static synchronized String SHA1(String input)
			throws NoSuchAlgorithmException {
		MessageDigest mDigest = MessageDigest.getInstance("SHA1");
		byte[] result = mDigest.digest(input.getBytes());
		StringBuffer sb = new StringBuffer();
		for (int i = 0; i < result.length; i++) {
			sb.append(Integer.toString((result[i] & 0xff) + 0x100, 16)
					.substring(1));
		}
		return sb.toString();
	}

	private static synchronized String MD5(String input)
			throws NoSuchAlgorithmException {
		String md5 = null;
		MessageDigest digest = MessageDigest.getInstance("MD5");
		digest.update(input.getBytes(), 0, input.length());
		md5 = new BigInteger(1, digest.digest()).toString(16);
		return md5;
	}

}
