package in.extremityindia.ibanking.apps.dao;

import in.extremityindia.ibanking.apps.beans.Account;
import in.extremityindia.ibanking.apps.beans.BankBranch;
import in.extremityindia.ibanking.apps.beans.City;
import in.extremityindia.ibanking.apps.beans.Location;
import in.extremityindia.ibanking.apps.beans.State;

import java.util.ArrayList;
import java.util.List;

public interface INewCustomerRegistrationDao {

	public List<State> getStateListDao();

	public List<City> getCityListDao(String sid);

	public List<Location> getLocationListDao(String cid);

	public List<BankBranch> getBankBranchListDao(String lid);

	public List<BankBranch> getIFSCCodeListDao(String lid);

	public long checkAccountNumberDao();

	

	public void setAllCustomerInformationDao(String firstname, String lastname,
			String gender, String dob, String aod, String address,
			String state, String city, String acctype, String location,
			String branch, String ifsccode, long NEW_ACCOUNT_NUMBER,
			Integer PIN_NUMBER,String mobilenumber,String emailid,String amount);

	public String checkEmailDao(String emailid);

	public String checkMobileDao(String mobilenumber);

}
