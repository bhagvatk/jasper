package in.extremityindia.ibanking.apps.service;

public interface IEServicesService {
	public void submitATMService(Integer acno);
	public void submitDebitService(Integer acno);
	public void submitCreditService(Integer acno,String emp_type);
	public void submitCheckbookService(Integer acno,Integer no_of_leaves);
}
