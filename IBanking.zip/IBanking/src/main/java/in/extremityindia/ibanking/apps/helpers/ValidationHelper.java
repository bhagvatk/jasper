package in.extremityindia.ibanking.apps.helpers;

import in.extremityindia.ibanking.apps.beans.Account;

import java.util.List;

public class ValidationHelper {

	public static boolean isValidUsername(String username) {
		return true;
	}

	public static boolean isValidPassword(String password) {
		return true;
	}
	
	public static String isValidAccountId(List<Account> accountIdlist,String account_id){
		try
		{
		int account_id1=Integer.parseInt(account_id);
		for(Account account:accountIdlist)
		{
			
			if(account.getAccountId()==account_id1)
			{
				return account_id;
			}
		}
		}
		catch(NumberFormatException e)
		{
			return "Account Number Is Incorrect..";
		}
		return "Account Number Is Incorrect.."; 
	}


	public static String isValidSecurityPin(String pinIn) {

		try {
			if (pinIn.length()!=4) {
					
			return "Security Pin is a 4 digit number.";
			}
			Integer.parseInt(pinIn);
		} catch (NumberFormatException e) {
//					"Security Pin must be only numbers.");
			return "Security Pin must be only numbers.";
		}
		return pinIn;
	}
	
	public static String isValidAmount(String amount) {
		try {
			double amountD = Double.parseDouble(amount);
			if (amountD < 1) {
//						"Amount should be greter than 0.");
				return "Amount should be greter than 0.";
			}
		} catch (NumberFormatException e) {
			// "Amount is not a valid value.");
			return "Amount is not a valid value";
		}
		return amount;
	}
}
