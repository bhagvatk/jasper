package in.extremityindia.ibanking.apps.service;

import in.extremityindia.ibanking.apps.beans.BankBranch;
import in.extremityindia.ibanking.apps.beans.City;
import in.extremityindia.ibanking.apps.beans.Location;
import in.extremityindia.ibanking.apps.beans.State;
import in.extremityindia.ibanking.apps.beans.User;

import java.util.List;

public interface INewCustomerRegisterService{
	
	/**
	 * @ TANVEER BOBADE
	 */
		public List<State> getStateListService();

		public List<City> getCityListService(String sid);

		public List<Location> getLocationListService(String cid);

		public List<BankBranch> getBankBranchListService(String lid);

		public List<BankBranch> getIFSCCodeListService(String lid);

		public void setCustomerInformationService(String firstname,
				String lastname, String gender, String dob, String aod,
				String address, String state, String city, String acctype,
				String location, String branch, String ifsccode,String mobilenumber,String emailid,String amount);

		public String checkEmailService(String emailid);

		public String checkMobileService(String mobilenumber);

		
	
		
}
