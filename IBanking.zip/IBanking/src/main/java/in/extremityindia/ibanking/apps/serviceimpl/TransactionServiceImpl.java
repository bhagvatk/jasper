package in.extremityindia.ibanking.apps.serviceimpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import in.extremityindia.ibanking.apps.beans.Account;
import in.extremityindia.ibanking.apps.beans.MapAccountCustomer;
import in.extremityindia.ibanking.apps.dao.ITransactionDao;
import in.extremityindia.ibanking.apps.exceptions.PinNotFoundException;
import in.extremityindia.ibanking.apps.helpers.ValidationHelper;
import in.extremityindia.ibanking.apps.service.ITransactionService;

public class TransactionServiceImpl implements ITransactionService{

	@Autowired
	ITransactionDao iTransactionDao;
	
	@Override
	public String validatePin(String pin){
	
		String pinIn= ValidationHelper.isValidSecurityPin(pin);
		return pinIn;
	}

	@Override
	public String validateAmount(String amount) {
	
		String amountcheck=ValidationHelper.isValidAmount(amount);		
		return amountcheck;
	}

	@Override
	public Double depositeAmount(String pin, String amount,int accountId,int customerId) {
	
		double TOTALAMOUNT=iTransactionDao.depositeAmount(pin, amount,accountId,customerId);
		return  TOTALAMOUNT;
				
	}

	@Override
	public String validateWithdrawAmount(String  amount) {
	     	String amountWithdrawCheck=ValidationHelper.isValidAmount(amount);
		return amountWithdrawCheck;
	}

	@Override
	public double getTotalAmount(String pin, int accountId) {
	          Double taotalAmount=  iTransactionDao.gettotalAmount(pin,accountId);
		return taotalAmount;
	}

	@Override
	public void withdrawAmount(String pin, String amount,int accountId ,int customerId) {
		
		iTransactionDao.withdrawAmount(pin,amount,accountId,customerId);
	}

	//**************************Transaction Count******************************
	@Override
	public List<String> getTransactionCount(int accountId) {
		return iTransactionDao.getTransactionCount(accountId);
		
	}

	/**********************Fund Transfer Methods**************************/
	@Override
	public List<Account> getAccountId() {
		
		return iTransactionDao.getAccountId();
	}

	@Override
	public MapAccountCustomer getAccountdata(int account_id) 
	{
		return iTransactionDao.getAccountdata(account_id);
	}
	
	public void fundtransfer(int customerId,int accountId,int accountIdTo,double transactionAmount,double useramount)
	{
		iTransactionDao.fundtransfer(customerId, accountId, accountIdTo,transactionAmount,useramount);
	}

	
	
	

}
