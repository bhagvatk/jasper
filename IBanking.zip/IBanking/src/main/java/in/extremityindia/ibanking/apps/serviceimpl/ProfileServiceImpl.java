package in.extremityindia.ibanking.apps.serviceimpl;



import org.springframework.beans.factory.annotation.Autowired;

import in.extremityindia.ibanking.apps.beans.Customer;
import in.extremityindia.ibanking.apps.beans.User;
import in.extremityindia.ibanking.apps.dao.IProfileDao;
import in.extremityindia.ibanking.apps.service.IProfileService;


public class ProfileServiceImpl implements IProfileService{
	@Autowired
	IProfileDao iprofiledao;

	

	@Override
	public int profileupadateservice(Customer customer) {
		System.out.println("====================profile service impl=================");
		// TODO Auto-generated method stub
	 return iprofiledao.profileupadate(customer);
	}



	@Override
	public int profilechangepasswordservice(User user) {
		// TODO Auto-generated method stub
		return iprofiledao.profilechangepassword(user);
	}

}
