package in.extremityindia.ibanking.apps.daoimpl;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Criterion;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;

import in.extremityindia.ibanking.apps.beans.Transaction;
import in.extremityindia.ibanking.apps.dao.IMyAccountDao;

public class MyAccountDaoImpl implements IMyAccountDao{
	
	@Autowired
	private SessionFactory hibernateSessionFactory;
	
	public void setSessionFactory(SessionFactory sf) {
		this.hibernateSessionFactory = sf;
	}

	@Override
	public List<Transaction> getMiniStatement(Integer accountid) {
		System.out.println("In dao getMiniStatement");
		Session session=hibernateSessionFactory.openSession();
		Query query=session.createQuery("select t.transactionTime,t.transactionAmount,t.transactionType from Transaction t where t.account.accountId=:id");
		//Criteria criteria=session.createCriteria(Transaction.class).add(Restrictions.eq("account", accountid));
		//List<Transaction> transactionList=criteria.list();
		List<Transaction> transactionList=query.setParameter("id", accountid).list();
		System.out.println("In dao transaction list:"+transactionList);
		return transactionList;
	}

}
