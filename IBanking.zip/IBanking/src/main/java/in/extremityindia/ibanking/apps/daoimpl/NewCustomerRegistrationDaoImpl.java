package in.extremityindia.ibanking.apps.daoimpl;

import in.extremityindia.ibanking.apps.beans.Account;
import in.extremityindia.ibanking.apps.beans.BankBranch;
import in.extremityindia.ibanking.apps.beans.City;
import in.extremityindia.ibanking.apps.beans.Customer;
import in.extremityindia.ibanking.apps.beans.Location;
import in.extremityindia.ibanking.apps.beans.State;
import in.extremityindia.ibanking.apps.dao.INewCustomerRegistrationDao;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.criterion.Criterion;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.MailSender;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;

public class NewCustomerRegistrationDaoImpl implements
		INewCustomerRegistrationDao {

	/**
	 * @ TANVEER BOBADE
	 */
	@Autowired
	SessionFactory sessionFactory;
	@Autowired
	private JavaMailSender mailSender;

	public static long REGISTERED_ACCOUNT_NUMBER;
	public static int REGISTERED_PIN_NUMBER;
	public static String REGISTERED_ACCOUNT_TYPE;
	public static String REGISTERED_ACCOUNT_BRANCH;
	public static String REGISTERED_ACCOUNT_LOCATION;
	public static String REGISTERED_ACCOUNT_STATE;
	public static String REGISTERED_ACCOUNT_CITY;
	public static String REGISTERED_ACCOUNT_IFSC;
	public static String REGISTERED_ACCOUNT_AMOUNT;

	public void setSessionFactory(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}

	@Override
	public List<State> getStateListDao() {

		Session session = sessionFactory.openSession();
		Query query = session.createQuery("From State s");
		System.out.println("in dao");
		List<State> statelist = query.list();
		System.out.println(statelist);
		return statelist;
	}

	@Override
	public List<City> getCityListDao(String sid) {
		Session session = sessionFactory.openSession();
		Integer intSid = Integer.parseInt(sid);
		Query query = session
				.createQuery("from City c where c.state.stateId = :code ");
		List<City> cityList = query.setParameter("code", intSid).list();

		System.out.println(cityList);

		return cityList;

	}

	@Override
	public List<Location> getLocationListDao(String cid) {
		Session session = sessionFactory.openSession();
		Integer intCid = Integer.parseInt(cid);

		Query query = session
				.createQuery("from Location l where l.city.cityId = :code ");
		List<Location> locList = query.setParameter("code", intCid).list();

		System.out.println(locList);

		return locList;
	}

	@Override
	public List<BankBranch> getBankBranchListDao(String lid) {
		Session session = sessionFactory.openSession();
		Integer intLid = Integer.parseInt(lid);

		Query query = session
				.createQuery("from BankBranch b where b.location.locId = :code ");
		List<BankBranch> branchList = query.setParameter("code", intLid).list();

		System.out.println(branchList);

		return branchList;
	}

	public List<BankBranch> getIFSCCodeListDao(String lid) {
		Session session = sessionFactory.openSession();
		Integer intlid = Integer.parseInt(lid);

		Query query = session
				.createQuery("from BankBranch b where b.bankBranchId = :code ");
		List<BankBranch> branchList = query.setParameter("code", intlid).list();

		System.out.println(branchList);

		return branchList;
	}

	@Override
	public long checkAccountNumberDao() {
		Session session = sessionFactory.openSession();
		long LAST_ACCOUNT_NUMBER=0;
try{
		Criteria criteria = session.createCriteria(Account.class)
				.setProjection(Projections.max("accountId"));
		Integer OLD_ACCOUNT_NUMBER = (Integer) criteria.uniqueResult();

		System.out.println("--------------------------------"
				+ OLD_ACCOUNT_NUMBER);
		 LAST_ACCOUNT_NUMBER = (long) OLD_ACCOUNT_NUMBER;
		System.out.println("***************   " + LAST_ACCOUNT_NUMBER);
}
catch(Exception e)
{
	
	LAST_ACCOUNT_NUMBER=0;
}
		return LAST_ACCOUNT_NUMBER;
	}

	@Override
	public void setAllCustomerInformationDao(String firstname, String lastname,
			String gender, String dob, String aod, String address,
			String state, String city, String acctype, String location,
			String branch, String ifsccode, long NEW_ACCOUNT_NUMBER,
			Integer PIN_NUMBER, String mobilenumber, String emailid,
			String amount) {
		Session session = sessionFactory.openSession();
		Transaction transaction = session.beginTransaction();
		firstname = firstname.toUpperCase();
		lastname = lastname.toUpperCase();
		gender = gender.toUpperCase();
		address = address.toUpperCase();
		state = state.toUpperCase();

		int account_type = 0;
		if (acctype.equals("SAVING")) {
			account_type = 1;
		} else if (acctype.equals("CURRENT")) {
			account_type = 2;
		} else {
			account_type = 3;
		}

		Query query = session
				.createSQLQuery("INSERT INTO customer (fname,lname,address,gender,nationality,date_of_birth,date_of_join,email,mobilenumber) VALUES ('"
						+ firstname
						+ "','"
						+ lastname
						+ "','"
						+ address
						+ "','"
						+ gender
						+ "','INDIA','"
						+ dob
						+ "','"
						+ aod
						+ "','" + emailid + "','" + mobilenumber + "')");
		int i = query.executeUpdate();
		Criteria cri = session.createCriteria(Customer.class).setProjection(
				Projections.max("customerId"));
		Integer CUSTOMER_ID = (Integer) cri.uniqueResult();
//account_id, pin, amount, account_type, bank_branch_id, atm_status, checkbook_leaves, checkbook_status, credit_employment_type, credit_status, debit_status
		Query query1 = session
				.createSQLQuery("INSERT INTO account (account_id,pin,amount,account_type,bank_branch_id, atm_status, checkbook_leaves, checkbook_status, credit_employment_type, credit_status, debit_status) VALUES ('"
						+ NEW_ACCOUNT_NUMBER
						+ "','"
						+ PIN_NUMBER
						+ "','"
						+ amount + "','" + account_type + "','" + branch + "','Pending','Pending','Pending','Pending','Pending','Pending')");
		int i1 = query1.executeUpdate();

		Query q = session
				.createSQLQuery("INSERT into map_account_customer(account_id,customer_id) values ('"
						+ NEW_ACCOUNT_NUMBER + "','" + CUSTOMER_ID + "')");
		int k = q.executeUpdate();

		Query q2 = session
				.createQuery("SELECT s.stateName FROM State s where stateId="
						+ state);
		Iterator iterator = q2.list().iterator();
		while (iterator.hasNext()) {
			String stateName = (String) iterator.next();
			REGISTERED_ACCOUNT_STATE = stateName;

		}
		Query selectCity = session
				.createQuery("SELECT c.cityName FROM City c where cityId="
						+ city);

		Iterator iterator2 = selectCity.list().iterator();
		while (iterator2.hasNext()) {
			String cityName = (String) iterator2.next();
			REGISTERED_ACCOUNT_CITY = cityName;

		}
		Query query5 = session
				.createQuery("SELECT b.name FROM BankBranch b where bankBranchId="
						+ branch);
		Iterator iterator3 = query5.list().iterator();
		while (iterator3.hasNext()) {
			String branchName = (String) iterator3.next();
			REGISTERED_ACCOUNT_BRANCH = branchName;

		}

		Query query6 = session
				.createQuery("SELECT b.ifsc FROM BankBranch b where bankBranchId="
						+ branch);
		Iterator iterator4 = query6.list().iterator();
		while (iterator4.hasNext()) {
			String ifsc = (String) iterator4.next();
			REGISTERED_ACCOUNT_IFSC = ifsc;
		}

		Query locationQuery = session
				.createQuery("SELECT l.locName FROM Location l where locId="
						+ location);
		Iterator itrLocation = locationQuery.list().iterator();
		while (itrLocation.hasNext()) {
			String locationName = (String) itrLocation.next();
			REGISTERED_ACCOUNT_LOCATION = locationName;
		}
		transaction.commit();

		REGISTERED_ACCOUNT_NUMBER = NEW_ACCOUNT_NUMBER;
		REGISTERED_PIN_NUMBER = PIN_NUMBER;
		REGISTERED_ACCOUNT_TYPE = acctype;
		REGISTERED_ACCOUNT_AMOUNT = amount;

		// takes input for e-mail
		String recipientAddress = emailid;
		String subject = "ONLINE MONEY BANKING Welcomes you to family";
		String message = "Dear" + " "
				+ firstname
				+ " "
				+ lastname
				+ " "
				+ ","
				+ "\n\n"
				+ "ONLINE MONEY BANKING Welcomes you to family "

				+ "\nYour "
				+ REGISTERED_ACCOUNT_TYPE
				+ " Account created with us in "
				+ REGISTERED_ACCOUNT_BRANCH
				+ " branch , "
				+ REGISTERED_ACCOUNT_LOCATION
				+ ", "
				+ REGISTERED_ACCOUNT_CITY
				+ " "
				+ REGISTERED_ACCOUNT_STATE
				+ "."
				+ "\n"
				+ "\n"
				+ "Your Account Balance :"
				+ REGISTERED_ACCOUNT_AMOUNT
				+ ".00 Rs"
				+ "\n"
				+ "\n"
				+ "Your Account Number :"
				+ REGISTERED_ACCOUNT_NUMBER
				+ "\n"
				+ "\n"
				+ "Your Confidential Pin Number :"
				+ REGISTERED_PIN_NUMBER
				+ "\n"
				+ "\n"
				+ "Branch Name :"
				+ REGISTERED_ACCOUNT_BRANCH
				+ "\n"
				+ "\n"
				+ "IFSC CODE :"
				+ REGISTERED_ACCOUNT_IFSC
				+ ""
				+ "\n"
				+ "\n"
				+ "Your account is valuable for us,Thank You for choosing ONLINE MONEY BANKING"
				+ "" + "\n" + "\n" + "Regards" + "" + "\n"
				+ "ADMINISTRATOR (ONLINE MONEY BANKING)" + "";

		// prints debug info
		System.out.println("To: " + recipientAddress);
		System.out.println("Subject: " + subject);
		System.out.println("Message: " + message);

		// creates a simple e-mail object
		SimpleMailMessage email = new SimpleMailMessage();
		email.setTo(recipientAddress);
		email.setSubject(subject);
		email.setText(message);

		// sends the e-mail
		mailSender.send(email);

	}

	@Override
	public String checkEmailDao(String emailid) {
		Session session = sessionFactory.openSession();
		// Query
		// query=session.createSQLQuery("SELECT c.email FROM Customer c where email="+emailid);
		String EMAIL_ID = "";
		Criteria cri = session.createCriteria(Customer.class);
		Criterion cn = Restrictions.eq("email", emailid);
		cri.add(cn);

		List l = cri.list();
		System.out.println("List total size..._" + l.size());
		Iterator it = l.iterator();

		while (it.hasNext()) {
			Customer c = (Customer) it.next();
			System.out.println(c.getEmail());

			EMAIL_ID = c.getEmail();
		}

		return EMAIL_ID;
	}

	@Override
	public String checkMobileDao(String mobilenumber) {

		Session session = sessionFactory.openSession();
		String MOBILE_NUMBER = "";
		Criteria cri = session.createCriteria(Customer.class);
		Criterion cn = Restrictions.eq("mobilenumber", mobilenumber);
		cri.add(cn);

		List l = cri.list();
		System.out.println("List total size..._" + l.size());
		Iterator it = l.iterator();

		while (it.hasNext()) {
			Customer c = (Customer) it.next();
			System.out.println(c.getMobilenumber());

			MOBILE_NUMBER = c.getMobilenumber();
		}

		return MOBILE_NUMBER;

	}

}
