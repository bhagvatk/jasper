package in.extremityindia.ibanking.apps.helpers;

public class BranchIFSCCreationHelper {

	
	public static String CONSTANT_IFSC="OMB"; 
	public static int CONSTANT_IFSC_SERIAL_NUMBER=10000000; 
	public static String createIFSCCode(int iFSC_INTEGER)
	{
		if(iFSC_INTEGER==0)
		{
			String	UNIQUE_IFSC_CODE=CONSTANT_IFSC+CONSTANT_IFSC_SERIAL_NUMBER;
			
			System.out.println(UNIQUE_IFSC_CODE);
		
			return UNIQUE_IFSC_CODE;

	
		}
	
		else{
			
			iFSC_INTEGER++;
			String	UNIQUE_IFSC_CODE=CONSTANT_IFSC+iFSC_INTEGER;
		
		System.out.println(UNIQUE_IFSC_CODE);
	
		return UNIQUE_IFSC_CODE;

		}
		}
	
	
}
