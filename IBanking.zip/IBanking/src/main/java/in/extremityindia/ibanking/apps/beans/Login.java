package in.extremityindia.ibanking.apps.beans;

import java.io.Serializable;
import javax.persistence.*;
import java.util.Date;


/**
 * The persistent class for the login database table.
 * 
 */
@Entity
@NamedQuery(name="Login.findAll", query="SELECT l FROM Login l")
public class Login implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int loginID;

	@Temporal(TemporalType.TIMESTAMP)
	private Date loginDate;

	@Temporal(TemporalType.TIMESTAMP)
	private Date logoutDate;

	private String uname;

	private String userHostName;

	private String userIpAdd;

	//bi-directional many-to-one association to Customer
	@ManyToOne
	@JoinColumn(name="customer_id")
	private Customer customer;

	public Login() {
	}

	public int getLoginID() {
		return this.loginID;
	}

	public void setLoginID(int loginID) {
		this.loginID = loginID;
	}

	public Date getLoginDate() {
		return this.loginDate;
	}

	public void setLoginDate(Date loginDate) {
		this.loginDate = loginDate;
	}

	public Date getLogoutDate() {
		return this.logoutDate;
	}

	public void setLogoutDate(Date logoutDate) {
		this.logoutDate = logoutDate;
	}

	public String getUname() {
		return this.uname;
	}

	public void setUname(String uname) {
		this.uname = uname;
	}

	public String getUserHostName() {
		return this.userHostName;
	}

	public void setUserHostName(String userHostName) {
		this.userHostName = userHostName;
	}

	public String getUserIpAdd() {
		return this.userIpAdd;
	}

	public void setUserIpAdd(String userIpAdd) {
		this.userIpAdd = userIpAdd;
	}

	public Customer getCustomer() {
		return this.customer;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}

}