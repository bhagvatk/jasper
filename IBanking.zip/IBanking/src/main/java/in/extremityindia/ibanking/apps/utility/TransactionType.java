package in.extremityindia.ibanking.apps.utility;

public class TransactionType {

	// SAVING account transaction type is 1
	public static final Integer SAVING = 1;

	// CURRENT account transaction type is 2
	public static final Integer CURRENT = 2;

	// CHECKING account transaction type is 3
	public static final Integer CHECKING = 3;

}
