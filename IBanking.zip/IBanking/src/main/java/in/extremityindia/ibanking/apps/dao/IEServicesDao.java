package in.extremityindia.ibanking.apps.dao;

public interface IEServicesDao {
	public void submitATMDao(Integer acno);
	public void submitDebitDao(Integer acno);
	public void submitCreditDao(Integer acno,String emp_type);
	public void submitCheckbookDao(Integer acno,Integer no_of_leaves);
}
