package in.extremityindia.ibanking.apps.service;

import in.extremityindia.ibanking.apps.beans.Customer;
import in.extremityindia.ibanking.apps.beans.User;

import java.util.List;

public interface IProfileService {

	public abstract int profileupadateservice(Customer customer);
	public abstract int profilechangepasswordservice(User user);
}
