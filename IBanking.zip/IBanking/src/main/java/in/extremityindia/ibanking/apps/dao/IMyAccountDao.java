package in.extremityindia.ibanking.apps.dao;
import java.util.*;
import in.extremityindia.ibanking.apps.beans.*;

public interface IMyAccountDao {
	public List<Transaction> getMiniStatement(Integer accountid);
}
