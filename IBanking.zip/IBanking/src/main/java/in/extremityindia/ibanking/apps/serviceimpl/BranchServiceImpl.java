package in.extremityindia.ibanking.apps.serviceimpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import in.extremityindia.ibanking.apps.beans.BankBranch;
import in.extremityindia.ibanking.apps.dao.IBranchDao;
import in.extremityindia.ibanking.apps.helpers.BranchIFSCCreationHelper;
import in.extremityindia.ibanking.apps.service.IBranchService;

public class BranchServiceImpl implements IBranchService {

	@Autowired
	IBranchDao iBranchDao;

	@Override
	public List<BankBranch> getBranchList() {
		return iBranchDao.getBranchList();
	}

	@Override
	public void insertBranches(BankBranch bankBranch) {
		
		int IFSC_INTEGER = iBranchDao.checkIFSC();
		
		String IFSC_BY_HELPER = (String) BranchIFSCCreationHelper.createIFSCCode(IFSC_INTEGER);
		System.out.println("Helper" + IFSC_BY_HELPER);
		int INTEGER_IFSC_HELPER = Integer.parseInt(IFSC_BY_HELPER.substring(3,11));
		IFSC_BY_HELPER.substring(3, 11);
		System.out.println("INTEGER_BY_HELPER" + INTEGER_IFSC_HELPER);
		System.out.println(IFSC_INTEGER);
		bankBranch.setIfsc(IFSC_BY_HELPER);
		iBranchDao.insertBranches(bankBranch);
	}

}
