package in.extremityindia.ibanking.apps.beans;

import java.io.Serializable;
import javax.persistence.*;
import java.util.Set;


/**
 * The persistent class for the bank_branch database table.
 * 
 */
@Entity
@Table(name="bank_branch")
@NamedQuery(name="BankBranch.findAll", query="SELECT b FROM BankBranch b")
public class BankBranch implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="bank_branch_id")
	private int bankBranchId;

	private String description;

	private String ifsc;

	private String name;

	//bi-directional many-to-one association to Account
	@OneToMany(mappedBy="bankBranch")
	private Set<Account> accounts;

	//bi-directional many-to-one association to Location
	@ManyToOne
	@JoinColumn(name="location_id")
	private Location location;

	public BankBranch() {
	}

	public int getBankBranchId() {
		return this.bankBranchId;
	}

	public void setBankBranchId(int bankBranchId) {
		this.bankBranchId = bankBranchId;
	}

	public String getDescription() {
		return this.description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getIfsc() {
		return this.ifsc;
	}

	public void setIfsc(String ifsc) {
		this.ifsc = ifsc;
	}

	public String getName() {
		return this.name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Set<Account> getAccounts() {
		return this.accounts;
	}

	public void setAccounts(Set<Account> accounts) {
		this.accounts = accounts;
	}

	public Account addAccount(Account account) {
		getAccounts().add(account);
		account.setBankBranch(this);

		return account;
	}

	public Account removeAccount(Account account) {
		getAccounts().remove(account);
		account.setBankBranch(null);

		return account;
	}

	public Location getLocation() {
		return this.location;
	}

	public void setLocation(Location location) {
		this.location = location;
	}

}