package in.extremityindia.ibanking.apps.service;

import in.extremityindia.ibanking.apps.beans.Account;

import java.util.List;

public interface IApprovalService {
	
	public List<Account> getATMStatusPending();
	
	public List<Account> getDebitStatusPending();
	
	public List<Account> getCreditStatusPending();
	
	public List<Account> getCheckBookStatusPending();
	

	public void setATMStatusApprove(Integer accountId);
	
	public void setDebitStatusApprove(Integer accountId);
	
	public void setCredittatusApprove(Integer accountId);
	
	public void setCheckBookStatusApprove(Integer accountId);
	
}
