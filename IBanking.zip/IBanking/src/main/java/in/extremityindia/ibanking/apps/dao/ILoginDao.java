package in.extremityindia.ibanking.apps.dao;

import in.extremityindia.ibanking.apps.beans.User;
import java.util.List;

public interface ILoginDao {
	public List<User> loginCheck(User user);
}
