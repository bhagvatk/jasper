package in.extremityindia.ibanking.apps.beans;

import java.io.Serializable;
import javax.persistence.*;
import java.util.Set;


/**
 * The persistent class for the account database table.
 * 
 */
@Entity
@NamedQuery(name="Account.findAll", query="SELECT a FROM Account a")
public class Account implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="account_id")
	private int accountId;

	@Column(name="account_type")
	private int accountType;

	private double amount;

	private int pin;
	
	@Column(name="atm_status")
	private String atmStatus;
	
	@Column(name="debit_status")
	private String debitStatus;
	
	@Column(name="credit_status")
	private String creditStatus;
	
	@Column(name="credit_employment_type")
	private String creditEmploymentType;
	
	@Column(name="checkbook_status")
	private String checkbookStatus;
	
	@Column(name="checkbook_leaves")
	private String checkbookLeaves;

	//bi-directional many-to-one association to BankBranch
	@ManyToOne
	@JoinColumn(name="bank_branch_id")
	private BankBranch bankBranch;

	//bi-directional many-to-one association to MapAccountCustomer
	@OneToMany(mappedBy="account")
	private Set<MapAccountCustomer> mapAccountCustomers;

	//bi-directional many-to-one association to Transaction
	@OneToMany(mappedBy="account")
	private Set<Transaction> transactions;

	public Account() {
	}

	public int getAccountId() {
		return this.accountId;
	}

	public void setAccountId(int accountId) {
		this.accountId = accountId;
	}

	public int getAccountType() {
		return this.accountType;
	}

	public void setAccountType(int accountType) {
		this.accountType = accountType;
	}

	public double getAmount() {
		return this.amount;
	}

	public void setAmount(double amount) {
		this.amount = amount;
	}

	public int getPin() {
		return this.pin;
	}

	public void setPin(int pin) {
		this.pin = pin;
	}

	public String getAtmStatus() {
		return atmStatus;
	}

	public void setAtmStatus(String atmStatus) {
		this.atmStatus = atmStatus;
	}
	
	public String getDebitStatus() {
		return debitStatus;
	}

	public void setDebitStatus(String debitStatus) {
		this.debitStatus = debitStatus;
	}
	
	public String getCreditStatus() {
		return creditStatus;
	}

	public void setCreditStatus(String creditStatus) {
		this.creditStatus = creditStatus;
	}

	public String getCreditEmploymentType() {
		return creditEmploymentType;
	}

	public void setCreditEmploymentType(String creditEmploymentType) {
		this.creditEmploymentType = creditEmploymentType;
	}
	
	public String getCheckbookStatus() {
		return checkbookStatus;
	}

	public void setCheckbookStatus(String checkbookStatus) {
		this.checkbookStatus = checkbookStatus;
	}

	public String getCheckbookLeaves() {
		return checkbookLeaves;
	}

	public void setCheckbookLeaves(String checkbookLeaves) {
		this.checkbookLeaves = checkbookLeaves;
	}

	public BankBranch getBankBranch() {
		return this.bankBranch;
	}

	public void setBankBranch(BankBranch bankBranch) {
		this.bankBranch = bankBranch;
	}

	public Set<MapAccountCustomer> getMapAccountCustomers() {
		return this.mapAccountCustomers;
	}

	public void setMapAccountCustomers(Set<MapAccountCustomer> mapAccountCustomers) {
		this.mapAccountCustomers = mapAccountCustomers;
	}

	public MapAccountCustomer addMapAccountCustomer(MapAccountCustomer mapAccountCustomer) {
		getMapAccountCustomers().add(mapAccountCustomer);
		mapAccountCustomer.setAccount(this);

		return mapAccountCustomer;
	}

	public MapAccountCustomer removeMapAccountCustomer(MapAccountCustomer mapAccountCustomer) {
		getMapAccountCustomers().remove(mapAccountCustomer);
		mapAccountCustomer.setAccount(null);

		return mapAccountCustomer;
	}

	public Set<Transaction> getTransactions() {
		return this.transactions;
	}

	public void setTransactions(Set<Transaction> transactions) {
		this.transactions = transactions;
	}

	public Transaction addTransaction(Transaction transaction) {
		getTransactions().add(transaction);
		transaction.setAccount(this);

		return transaction;
	}

	public Transaction removeTransaction(Transaction transaction) {
		getTransactions().remove(transaction);
		transaction.setAccount(null);

		return transaction;
	}

}