package in.extremityindia.ibanking.apps.controllers;

import java.util.Iterator;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import in.extremityindia.ibanking.apps.beans.Account;
import in.extremityindia.ibanking.apps.beans.MapAccountCustomer;
import in.extremityindia.ibanking.apps.beans.User;
import in.extremityindia.ibanking.apps.service.IEServicesService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class EServicesController {
	
	@Autowired
	IEServicesService iEServicesService;
	Integer accId;

	@RequestMapping("/submitATMForm")
	public ModelAndView submitATMForm(@ModelAttribute User user,HttpServletRequest request){
		System.out.println("IN ESERVICES CONTROLLER");
		System.out.println("IN SUBMIT ATM FORM METHOD");
		  HttpSession session=request.getSession(); 
		  User u=(User)session.getAttribute("user");
		  Set map=u.getCustomer().getMapAccountCustomers();
		  Iterator itr=map.iterator();
		  while(itr.hasNext()){
			  MapAccountCustomer mapAc=(MapAccountCustomer)itr.next();
			  accId=mapAc.getAccount().getAccountId();
		  }
		iEServicesService.submitATMService(accId);
		return new ModelAndView("e-servicesmenu","ATMSuccessMsg","You applied Successfully.!");
	}
	
	@RequestMapping("/submitDebitForm")
	public ModelAndView submitDebitForm(@ModelAttribute User user,HttpServletRequest request){
		System.out.println("IN ESERVICES CONTROLLER");
		System.out.println("IN SUBMIT DEBIT FORM METHOD");
		HttpSession session=request.getSession(); 
		  User u=(User)session.getAttribute("user");
		  Set map=u.getCustomer().getMapAccountCustomers();
		  Iterator itr=map.iterator();
		  while(itr.hasNext()){
			  MapAccountCustomer mapAc=(MapAccountCustomer)itr.next();
			  accId=mapAc.getAccount().getAccountId();
		  }
		  iEServicesService.submitDebitService(accId);
		return new ModelAndView("e-servicesmenu","ATMSuccessMsg","You applied Successfully.!");
	}
	
	@RequestMapping("/submitCreditForm")
	public ModelAndView submitCreditForm(@ModelAttribute User user,HttpServletRequest request){
		System.out.println("IN ESERVICES CONTROLLER");
		System.out.println("IN SUBMIT CREDIT FORM METHOD");
		String emp_type=request.getParameter("employment_type");
		HttpSession session=request.getSession(); 
		  User u=(User)session.getAttribute("user");
		  Set map=u.getCustomer().getMapAccountCustomers();
		  Iterator itr=map.iterator();
		  while(itr.hasNext()){
			  MapAccountCustomer mapAc=(MapAccountCustomer)itr.next();
			  accId=mapAc.getAccount().getAccountId();
		  }
		  iEServicesService.submitCreditService(accId,emp_type);
		return new ModelAndView("e-servicesmenu","ATMSuccessMsg","You applied Successfully.!");
	}
	
	@RequestMapping("/submitCheckBookAppln")
	public ModelAndView submitCheckBookAppln(@ModelAttribute User user,HttpServletRequest request){
		System.out.println("IN ESERVICES CONTROLLER");
		System.out.println("IN SUBMIT CHECK BOOK FORM METHOD");
		String no_of_leaves=request.getParameter("no_of_leaves");
		Integer leaves=Integer.parseInt(no_of_leaves);
		HttpSession session=request.getSession(); 
		  User u=(User)session.getAttribute("user");
		  Set map=u.getCustomer().getMapAccountCustomers();
		  Iterator itr=map.iterator();
		  while(itr.hasNext()){
			  MapAccountCustomer mapAc=(MapAccountCustomer)itr.next();
			  accId=mapAc.getAccount().getAccountId();
		  }
		  iEServicesService.submitCheckbookService(accId,leaves);
		return new ModelAndView("e-servicesmenu","ATMSuccessMsg","You applied Successfully.!");
	}
}
