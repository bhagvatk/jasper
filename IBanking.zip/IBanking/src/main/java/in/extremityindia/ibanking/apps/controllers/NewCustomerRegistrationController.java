package in.extremityindia.ibanking.apps.controllers;
import java.io.IOException;
import java.io.PrintWriter;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import in.extremityindia.ibanking.apps.beans.BankBranch;
import in.extremityindia.ibanking.apps.beans.City;
import in.extremityindia.ibanking.apps.beans.Location;
import in.extremityindia.ibanking.apps.beans.State;
import in.extremityindia.ibanking.apps.helpers.AccountCreationHelper;
import in.extremityindia.ibanking.apps.service.INewCustomerRegisterService;
import in.extremityindia.ibanking.apps.servicebusiness.AccountBusiness;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;
@Controller
public class NewCustomerRegistrationController {
	
	/**
	 * @ TANVEER BOBADE
	 */
	
	@Autowired
	INewCustomerRegisterService newCustomerRegisterService;	
	@RequestMapping(value = "/selectCities", method = { RequestMethod.GET,
			RequestMethod.POST })
	public @ResponseBody  void cityListResponse(@RequestParam String state_id,HttpServletRequest request,HttpServletResponse response) throws IOException {
		
		String sid=state_id;
		
		List<City> cityList=newCustomerRegisterService.getCityListService(sid);
		PrintWriter pw = response.getWriter();
		pw.write("<option>--Select City--</option>");
		Iterator<City> itr = cityList.iterator();
		while (itr.hasNext()) {
			City city = (City) itr.next();
			pw.write("<option value=" + city.getCityId()+ ">"
					+ city.getCityName().toUpperCase() + "</option>");
		}
	}
	@RequestMapping(value = "/selectLocation", method = { RequestMethod.GET,
			RequestMethod.POST })
	public @ResponseBody  void locationListResponse(@RequestParam String city_id,HttpServletRequest request,HttpServletResponse response) throws IOException {
		
		String cid=city_id;
		System.out.println("city ID"+cid);
		System.out.println("In Registration Controller");
		List<Location> cityList=newCustomerRegisterService.getLocationListService(cid);
		PrintWriter pw = response.getWriter();
		pw.write("<option>--Select Location--</option>");
		Iterator<Location> itr = cityList.iterator();
		while (itr.hasNext()) {
			Location loc = (Location)itr.next();
			pw.write("<option value=" + loc.getLocId()+ ">"
					+ loc.getLocName().toUpperCase() + "</option>");
		}
	}
@RequestMapping(value = "/customerReg", method = RequestMethod.GET)
	public ModelAndView customer(Model model) {
	
		List<State> stateList=newCustomerRegisterService.getStateListService();
		return new ModelAndView("customermenu","stateList",stateList) ;

	}
	@RequestMapping(value = "/selectBankBranch", method = { RequestMethod.GET,
			RequestMethod.POST })
	public @ResponseBody  void branchListResponse(@RequestParam String location_id,HttpServletRequest request,HttpServletResponse response) throws IOException {
	
		String lid=location_id;
		
		List<BankBranch> branchList=newCustomerRegisterService.getBankBranchListService(lid);
		PrintWriter pw = response.getWriter();
		pw.write("<option>--Select Branch--</option>");
		Iterator<BankBranch> itr = branchList.iterator();
		while (itr.hasNext()) {
			BankBranch bankBranch = (BankBranch)itr.next();
			pw.write("<option value=" + bankBranch.getBankBranchId()+ ">"
					+ bankBranch.getName().toUpperCase() + "</option>");
		}
	}
	@RequestMapping(value = "/selectIFSC", method = { RequestMethod.GET,
			RequestMethod.POST })
	public @ResponseBody  void ifscListResponse(@RequestParam String branch_id,HttpServletRequest request,HttpServletResponse response) throws IOException {
		//String lid=branch_id;
		List<BankBranch> ifscList=newCustomerRegisterService.getIFSCCodeListService(branch_id);
		PrintWriter pw = response.getWriter();
		pw.write("<option>--Select IFSC CODE--</option>");
		Iterator<BankBranch> itr = ifscList.iterator();
		while (itr.hasNext()) {
			BankBranch branch = (BankBranch)itr.next();
			pw.write("<option value=" + branch.getBankBranchId()+ ">"
					+ branch.getIfsc().toUpperCase() + "</option>");
		}
	}
	
	@RequestMapping(value = "/CheckBdate", method = { RequestMethod.GET,
			RequestMethod.POST })
	public @ResponseBody void checkBdate(@RequestParam String birthdate ,HttpServletRequest request,HttpServletResponse response) throws Exception
	{
		DateFormat dateFormat = new SimpleDateFormat("yyyy");
		Date date = new Date();
		String aod = dateFormat.format(date);
		System.out.println(aod);
		System.out.println(birthdate);
		String year="";	
		
	for(int i=0;i<=3;i++)
	{
		char str=birthdate.charAt(i);
		System.out.println(str);
		 year=year+str;
	}
	int birthYear=Integer.parseInt(year);
	int currentYear=Integer.parseInt(aod);
	
	if((currentYear-birthYear)<=18)
	{
		PrintWriter pw = response.getWriter();
		pw.write("<font color="+"red"+">"+" Customer is not eligible to open any type of account in Bank (Age must be greater than 18 years)"+"</font>");
	}
	else
	{
		PrintWriter pw = response.getWriter();
		pw.write("<font color="+"green"+">"+" Customer is eligible to open any type of account in Bank"+"</font>");
	}
	
	
	
	}
	@RequestMapping(value = "/CheckEmail", method = { RequestMethod.GET,
			RequestMethod.POST })
	public @ResponseBody void checkEmail(@RequestParam String emailid ,HttpServletRequest request,HttpServletResponse response) throws Exception
	{
		String EMAIL_ID=newCustomerRegisterService.checkEmailService(emailid);
	if(emailid=="")
	{
		PrintWriter pw = response.getWriter();
		pw.write("<font color="+"red"+">"+"Please Enter Valid Email ID"+"</font>");
	}		
		else if(EMAIL_ID.equals(emailid))
		{
			PrintWriter pw = response.getWriter();
			pw.write("<font color="+"red"+">"+EMAIL_ID+""+" already exist in the system database"+"</font>");
		}
		else
		{
			PrintWriter pw = response.getWriter();
			pw.write("<font color="+"green"+">"+" Email ID accepted by system database"+"</font>");
		}

	
	}
	
	@RequestMapping(value = "/checkAmount", method = { RequestMethod.GET,
			RequestMethod.POST })
	public @ResponseBody void checkAmount(@RequestParam String amount ,HttpServletRequest request,HttpServletResponse response) throws Exception
	{
		int newAmount=Integer.parseInt(amount);
		if (newAmount<1000)
		{
			PrintWriter pw = response.getWriter();
			pw.write("<font color="+"red"+">"+" Please pay minimum 1000 Rs to open new account"+"</font>");
		}
		else
		{
			PrintWriter pw = response.getWriter();
			pw.write("<font color="+"green"+">"+" You have paid  account opening amount to bank,your amount will be deposited in your account	"+"</font>");
		}
	
	}

	@RequestMapping(value = "/CheckMobile", method = { RequestMethod.GET,
			RequestMethod.POST })

	
	public @ResponseBody void checkMobile(@RequestParam String mobile_no ,HttpServletRequest request,HttpServletResponse response) throws Exception
	{
		if(mobile_no=="")
		{
			PrintWriter pw = response.getWriter();
			pw.write("<font color="+"red"+">"+mobile_no+""+" Mobile number canot be empty,Please enter 10 digits mobile number (Ex.9400000000)"+"</font>");
		}
		else if(mobile_no.length()<10||mobile_no.length()>10)
		{
			PrintWriter pw = response.getWriter();
			pw.write("<font color="+"red"+">"+mobile_no+""+" is not a valid mobile number,Please enter 10 digits mobile number (Ex.9400000000)"+"</font>");
		}
		else if(mobile_no.length()==10)
		{
			String mobilenumber1=newCustomerRegisterService.checkMobileService(mobile_no);
		if(mobilenumber1.equals(mobile_no))
		{
			PrintWriter pw = response.getWriter();
			pw.write("<font color="+"red"+">"+mobilenumber1+""+" mobile number Already Exist"+"</font>");
		}
		else
		{
			PrintWriter pw = response.getWriter();
			pw.write("<font color="+"green"+">"+" Mobile number accepted by system database"+"</font>");
		}

		}
		else
		{
			PrintWriter pw = response.getWriter();
			pw.write("<font color="+"green"+">"+" Mobile number accepted by system database"+"</font>");
		}
	}
	
	@RequestMapping(value = "/registerCustomer", method = { RequestMethod.GET,
			RequestMethod.POST })
	public ModelAndView genrateAccount(@RequestParam String mobilenumber,String emailid, String firstname,String lastname,String gender,String dob,String address,String state,String city,String location,String branch,String ifsccode,String acctype,String amount) throws Exception
	{
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
		Date date = new Date();
		String aod = dateFormat.format(date);
		newCustomerRegisterService.setCustomerInformationService(firstname,lastname,gender,dob,aod,address,state,city,acctype,location,branch,ifsccode,mobilenumber,emailid,amount);
		String msg="Customer Registered Successfully";
		return new ModelAndView("adminHome","message",msg);
	}
	
	
	
	
	
	
	
	
	
	
}
