$(function() {
	$("#atmapproval").click(function() {
		
				$("#atmapprovalbody").show(), 
				$("#debitapprovalbody").hide(),
				$("#creditapprovalbody").hide(), 
				$("#checkbookapprovalbody").hide()
			}), 
			$("#debitapproval").click(function() {
				$("#debitapprovalbody").show();
				
				$("#creditapprovalbody").hide(), 
				$("#checkbookapprovalbody").hide(), 
				$("#atmapprovalbody").hide()
			}), 
			$("#checkapproval").click(function() {
				$("#checkbookapprovalbody").show();
				$("#debitapprovalbody").hide(), 
				$("#creditapprovalbody").hide(), 
				$("#atmapprovalbody").hide()
			}), 
			$("#creditapproval").click(function() {
				$("#creditapprovalbody").show();
				$("#debitapprovalbody").hide(), 
				$("#checkbookapprovalbody").hide(), 
				$("#atmapprovalbody").hide()
			}), 
			$("#debitapprovalbody").hide(),
			$("#creditapprovalbody").hide(), 
			$("#checkbookapprovalbody").hide()
});