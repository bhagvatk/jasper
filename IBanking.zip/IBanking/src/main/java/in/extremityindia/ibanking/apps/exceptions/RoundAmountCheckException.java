package in.extremityindia.ibanking.apps.exceptions;

public class RoundAmountCheckException extends Exception{

	 public RoundAmountCheckException(String msg) {
		super(msg);
	}
}
