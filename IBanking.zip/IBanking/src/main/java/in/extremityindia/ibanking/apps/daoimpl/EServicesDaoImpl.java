package in.extremityindia.ibanking.apps.daoimpl;

import org.hibernate.Query;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;

import in.extremityindia.ibanking.apps.beans.Account;
import in.extremityindia.ibanking.apps.beans.User;
import in.extremityindia.ibanking.apps.dao.IEServicesDao;

public class EServicesDaoImpl implements IEServicesDao{
	
	@Autowired
	private SessionFactory hibernateSessionFactory;
	
	@Autowired
	Account account;
	
	public void setSessionFactory(SessionFactory sf) {
		this.hibernateSessionFactory = sf;
	}

	@Override
	public void submitATMDao(Integer acno) {
		System.out.println("IN ATM SUBMIT DAO");
		Session session=hibernateSessionFactory.openSession();
		String atmStatus="Pending";
		account.setAccountId(acno);
		account.setAtmStatus(atmStatus);
		System.out.println("Before Update");
		SQLQuery query=session.createSQLQuery("update account set atm_status=? where account_id="+acno);
		query.setParameter(0, atmStatus);
		query.executeUpdate();
		System.out.println("Updates Successfully");
	}

	@Override
	public void submitDebitDao(Integer acno) {
		System.out.println("IN DEBIT SUBMIT DAO");
		try {
			Session session=hibernateSessionFactory.openSession();
			String debitStatus="Pending";
			System.out.println("Before Update");
			SQLQuery query=session.createSQLQuery("update account set debit_status=? where account_id="+acno);
			query.setParameter(0, debitStatus);
			query.executeUpdate();
			System.out.println("Updates Successfully");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Override
	public void submitCreditDao(Integer acno,String emp_type) {
		System.out.println("IN CREDIT SUBMIT DAO");
		try {
			Session session=hibernateSessionFactory.openSession();
			String creditStatus="Pending";
			System.out.println("Before Update");
			SQLQuery query=session.createSQLQuery("update account set credit_status=?,credit_employment_type=? where account_id="+acno);
			query.setParameter(0, creditStatus);
			query.setParameter(1, emp_type);
			query.executeUpdate();
			System.out.println("Updates Successfully");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Override
	public void submitCheckbookDao(Integer acno, Integer no_of_leaves) {
		System.out.println("IN CHECK BOOK SUBMIT DAO");
		try {
			Session session=hibernateSessionFactory.openSession();
			String checkBookStatus="Pending";
			System.out.println("Before Update");
			SQLQuery query=session.createSQLQuery("update account set checkbook_status=?,checkbook_leaves=? where account_id="+acno);
			query.setParameter(0, checkBookStatus);
			query.setParameter(1, no_of_leaves);
			query.executeUpdate();
			System.out.println("Updates Successfully");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
