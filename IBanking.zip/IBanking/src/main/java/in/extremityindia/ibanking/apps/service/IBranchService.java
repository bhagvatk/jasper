package in.extremityindia.ibanking.apps.service;

import in.extremityindia.ibanking.apps.beans.BankBranch;

import java.util.List;

public interface IBranchService {

	public List<BankBranch> getBranchList();
	
	public void insertBranches(BankBranch bankBranch);
	
}
