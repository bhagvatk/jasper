package in.extremityindia.ibanking.apps.dao;

import in.extremityindia.ibanking.apps.beans.Account;
import in.extremityindia.ibanking.apps.beans.MapAccountCustomer;

import java.util.List;

public interface ITransactionDao 
{
	/**********************Deposit Withdraw Methods***********************/
	public Double depositeAmount(String pin,String amount,int accountId,int customerId);
	public Double gettotalAmount(String pin, int accountId);
	public void withdrawAmount(String pin, String amount, int accountId,int customerId);
	public List<String> getTransactionCount(int accountId);
	
	/**********************Fund Transfer Methods**************************/	
	MapAccountCustomer getAccountdata(int account_id);
	List<Account> getAccountId();
	public void fundtransfer(int customerId,int accountId,int accountIdTo,double transactionAmount,double useramount);
	
}
