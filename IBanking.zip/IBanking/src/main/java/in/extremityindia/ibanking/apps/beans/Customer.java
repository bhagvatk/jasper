package in.extremityindia.ibanking.apps.beans;

import java.io.Serializable;

import javax.persistence.*;

import java.sql.Timestamp;
import java.util.Date;
import java.util.Set;


/**
 * The persistent class for the customer database table.
 * 
 */
@Entity
@NamedQuery(name="Customer.findAll", query="SELECT c FROM Customer c")
public class Customer implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="customer_id")
	private int customerId;

	private String address;

	@Column(name="date_of_birth")
	private String dateOfBirth;

	@Column(name="date_of_join")
	private String dateOfJoin;

	private String fname;

	private String gender;

	private String lname;

	private String nationality;

	private String nric;
private String email;
	
	public String getEmail() {
	return email;
}

public void setEmail(String email) {
	this.email = email;
}

public String getMobilenumber() {
	return mobilenumber;
}

public void setMobilenumber(String mobilenumber) {
	this.mobilenumber = mobilenumber;
}

	private String mobilenumber;
	//bi-directional many-to-one association to Login
	@OneToMany(mappedBy="customer")
	private Set<Login> logins;

	//bi-directional many-to-one association to MapAccountCustomer
	@OneToMany(mappedBy="customer")
	private Set<MapAccountCustomer> mapAccountCustomers;

	//bi-directional many-to-one association to Transaction
	@OneToMany(mappedBy="customer")
	private Set<Transaction> transactions;

	//bi-directional many-to-one association to User
	@OneToMany(mappedBy="customer")
	private Set<User> users;

	public Customer() {
	}

	public int getCustomerId() {
		return this.customerId;
	}

	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}

	public String getAddress() {
		return this.address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getDateOfBirth() {
		return this.dateOfBirth;
	}

	public void setDateOfBirth(String dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}

	public String getDateOfJoin() {
		return this.dateOfJoin;
	}

	public void setDateOfJoin(String dateOfJoin) {
		this.dateOfJoin = dateOfJoin;
	}

	public String getFname() {
		return this.fname;
	}

	public void setFname(String fname) {
		this.fname = fname;
	}

	public String getGender() {
		return this.gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getLname() {
		return this.lname;
	}

	public void setLname(String lname) {
		this.lname = lname;
	}

	public String getNationality() {
		return this.nationality;
	}

	public void setNationality(String nationality) {
		this.nationality = nationality;
	}

	public String getNric() {
		return this.nric;
	}

	public void setNric(String nric) {
		this.nric = nric;
	}

	public Set<Login> getLogins() {
		return this.logins;
	}

	public void setLogins(Set<Login> logins) {
		this.logins = logins;
	}

	public Login addLogin(Login login) {
		getLogins().add(login);
		login.setCustomer(this);

		return login;
	}

	public Login removeLogin(Login login) {
		getLogins().remove(login);
		login.setCustomer(null);

		return login;
	}

	public Set<MapAccountCustomer> getMapAccountCustomers() {
		return this.mapAccountCustomers;
	}

	public void setMapAccountCustomers(Set<MapAccountCustomer> mapAccountCustomers) {
		this.mapAccountCustomers = mapAccountCustomers;
	}

	public MapAccountCustomer addMapAccountCustomer(MapAccountCustomer mapAccountCustomer) {
		getMapAccountCustomers().add(mapAccountCustomer);
		mapAccountCustomer.setCustomer(this);

		return mapAccountCustomer;
	}

	public MapAccountCustomer removeMapAccountCustomer(MapAccountCustomer mapAccountCustomer) {
		getMapAccountCustomers().remove(mapAccountCustomer);
		mapAccountCustomer.setCustomer(null);

		return mapAccountCustomer;
	}

	public Set<Transaction> getTransactions() {
		return this.transactions;
	}

	public void setTransactions(Set<Transaction> transactions) {
		this.transactions = transactions;
	}

	public Transaction addTransaction(Transaction transaction) {
		getTransactions().add(transaction);
		transaction.setCustomer(this);

		return transaction;
	}

	public Transaction removeTransaction(Transaction transaction) {
		getTransactions().remove(transaction);
		transaction.setCustomer(null);

		return transaction;
	}

	public Set<User> getUsers() {
		return this.users;
	}

	public void setUsers(Set<User> users) {
		this.users = users;
	}

	public User addUser(User user) {
		getUsers().add(user);
		user.setCustomer(this);

		return user;
	}

	public User removeUser(User user) {
		getUsers().remove(user);
		user.setCustomer(null);

		return user;
	}

}