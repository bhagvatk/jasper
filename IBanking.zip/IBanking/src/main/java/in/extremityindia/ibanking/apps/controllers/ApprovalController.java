package in.extremityindia.ibanking.apps.controllers;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import in.extremityindia.ibanking.apps.beans.Account;
import in.extremityindia.ibanking.apps.service.IApprovalService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class ApprovalController {

	@Autowired
	IApprovalService iApprovalService;

	@RequestMapping(value = "/statusPending.htm", method = { RequestMethod.GET,
			RequestMethod.POST })
	public ModelAndView getATMStatusPending() {

		Map<Integer, List<Account>> listMapper = new HashMap<Integer, List<Account>>();
		
		List<Account> atmList = iApprovalService.getATMStatusPending();
		List<Account> debitList = iApprovalService.getDebitStatusPending();
		List<Account> creditList = iApprovalService.getCreditStatusPending();
		List<Account> checkBookList = iApprovalService.getCheckBookStatusPending();
		
		listMapper.put(1, atmList);
		listMapper.put(2, debitList);
		listMapper.put(3, creditList);
		listMapper.put(4, checkBookList);

		return new ModelAndView("approvalmenu", "listMapper", listMapper);
	}

	@RequestMapping(value = "/atmStatusChange")
	public String atmApprovalStatus(@RequestParam Integer accountId) {
		System.out.println("IN ATM STATUS CHANGE");
		System.out.println("atm Status change acid:" + accountId);
		iApprovalService.setATMStatusApprove(accountId);
		return "redirect:/statusPending.htm";
	}

	/*
	 * @RequestMapping(value="/getDebitStatusPending", method =
	 * RequestMethod.GET) public @ResponseBody List<Account>
	 * getDebitStatusPending(){
	 * System.out.println("IN GET DEBIT STATUS PENDING"); List<Account>
	 * list=iApprovalService.getDebitStatusPending(); System.out.println(list);
	 * return list; }
	 */

	/*@RequestMapping(value = "/getDeibit", method = { RequestMethod.GET,
			RequestMethod.POST })
	@GET
	@Path("/")
	@Produces(MediaType.APPLICATION_JSON)
	public @ResponseBody List<Account> getDebit() {
		System.out.println("getDebit");
		List<Account> list = iApprovalService.getDebitStatusPending();
		return list;
	}

	@RequestMapping(value = "/getCredit", method = { RequestMethod.GET,
			RequestMethod.POST })
	@GET
	@Path("/")
	@Produces(MediaType.APPLICATION_JSON)
	public @ResponseBody List<Account> getCredit() {
		System.out.println("getCredit");
		List<Account> list = iApprovalService.getCreditStatusPending();
		return list;
	}

	@RequestMapping(value = "/getcheckbook", method = { RequestMethod.GET,
			RequestMethod.POST })
	@GET
	@Path("/")
	@Produces(MediaType.APPLICATION_JSON)
	public @ResponseBody List<Account> getcheckbook() {
		System.out.println("getcheckbook");
		List<Account> list = iApprovalService.getCheckBookStatusPending();
		return list;
	}*/
}
