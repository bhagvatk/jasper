package in.extremityindia.ibanking.apps.exceptions;


public class NotFoundException extends Exception {

	/**
	 * @author Rahul Moundekar
	 */
	private static final long serialVersionUID = 1L;

	public NotFoundException(String msg) {
		super(msg);
	}

}