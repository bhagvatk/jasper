package in.extremityindia.ibanking.apps.controllers;

import java.util.Iterator;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import in.extremityindia.ibanking.apps.beans.User;
import in.extremityindia.ibanking.apps.service.ILoginService;
import in.extremityindia.ibanking.apps.utility.Constants;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class LoginLogoutController {
	@Autowired
	ILoginService iLoginService;

	@RequestMapping(value = "userlogin", method = { RequestMethod.GET,
			RequestMethod.POST })
	public ModelAndView loginUser(@ModelAttribute User user,
			HttpServletRequest request) {

		System.out.println("login check");
		HttpSession session = request.getSession();
		List<User> logList = iLoginService.loginCheck(user);
		if (!logList.isEmpty()) {
			Iterator<User> itr = logList.iterator();
			while (itr.hasNext()) {
				user = itr.next();
				session.setAttribute("user", user);

				if (user.getRole().equals(Constants.ADMIN))
					return new ModelAndView("adminHome");
				else if (user.getRole().equals(Constants.CUSTOMER))
					return new ModelAndView("customerHome");
			}
		} else
			return new ModelAndView("globalHome");
		return new ModelAndView("globalHome");
	}

	@RequestMapping(value = "/logout", method = { RequestMethod.GET,
			RequestMethod.POST })
	public String logoutUserSession(HttpServletRequest request) {
		try {
			HttpSession session = request.getSession();
			session.invalidate();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return "redirect:/index.htm";
	}

}
