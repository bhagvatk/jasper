package in.extremityindia.ibanking.apps.serviceimpl;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import in.extremityindia.ibanking.apps.beans.Account;
import in.extremityindia.ibanking.apps.dao.IApprovalDao;
import in.extremityindia.ibanking.apps.service.IApprovalService;

public class ApprovalServiceImpl implements IApprovalService {

	@Autowired
	IApprovalDao iApprovalDao;

	@Override
	public List<Account> getATMStatusPending() {
		return iApprovalDao.getATMStatusPending();
	}

	@Override
	public List<Account> getDebitStatusPending() {
		return iApprovalDao.getDebitStatusPending();
	}

	@Override
	public List<Account> getCreditStatusPending() {
		return iApprovalDao.getCreditStatusPending();
	}

	@Override
	public List<Account> getCheckBookStatusPending() {
		return iApprovalDao.getCheckBookStatusPending();
	}

	@Override
	public void setATMStatusApprove(Integer accountId) {
		iApprovalDao.setATMStatusApprove(accountId);
	}

	@Override
	public void setDebitStatusApprove(Integer accountId) {
		iApprovalDao.setDebitStatusApprove(accountId);
	}

	@Override
	public void setCredittatusApprove(Integer accountId) {
		iApprovalDao.setCredittatusApprove(accountId);
	}

	@Override
	public void setCheckBookStatusApprove(Integer accountId) {
		iApprovalDao.setCheckBookStatusApprove(accountId);
	}

}
