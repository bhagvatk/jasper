package in.extremityindia.ibanking.apps.serviceimpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import in.extremityindia.ibanking.apps.beans.Transaction;
import in.extremityindia.ibanking.apps.dao.IMyAccountDao;
import in.extremityindia.ibanking.apps.service.IMyAccountService;

public class MyAccountServiceImpl implements IMyAccountService{
	
	@Autowired
	IMyAccountDao iMyAccountDao;

	@Override
	public List<Transaction> getMiniStatement(Integer accountid) {
		return iMyAccountDao.getMiniStatement(accountid);
	}

}
