package in.extremityindia.ibanking.apps.controllers;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import in.extremityindia.ibanking.apps.beans.Customer;
import in.extremityindia.ibanking.apps.beans.User;
import in.extremityindia.ibanking.apps.service.IProfileService;







import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class ProfileController {
	@Autowired
	IProfileService iprofileservice;
	@RequestMapping(value="updateprofile", method = { RequestMethod.GET,	RequestMethod.POST })
	public String profilecontroller(@ModelAttribute Customer customer,@RequestParam String fname,HttpServletRequest request)
	{
		System.out.println("in profile controller======of personaldeatails");
		HttpSession session=request.getSession();
		User userlist= (User)session.getAttribute("user");
		int custmer_id= userlist.getCustomer().getCustomerId();
		customer.setCustomerId(custmer_id);
		System.out.println("get user id="+userlist.getUId());
		System.out.println("FIRSTNAME:"+fname);
		System.out.println("custo name===="+customer.getFname());
		System.out.println("dob ="+customer.getDateOfBirth());
		System.out.println("doj="+customer.getDateOfJoin());
		System.out.println(customer.getCustomerId());
		System.out.println(customer.getLname()+customer.getAddress());
		
		int result=iprofileservice.profileupadateservice(customer);
		if(result>0)
		{
			return "redirect:/profile.htm";
		}
		else
		{
			return "profilemenu";
			//return new ModelAndView("profilemenu");
		}
	}

	@RequestMapping(value="/changepassowrd",method= { RequestMethod.GET,	RequestMethod.POST })
	public ModelAndView profilechangepassword(@ModelAttribute User user,@RequestParam String pass,HttpServletRequest request)
	{
		System.out.println("===============================================in chnage passowrd==========");
		HttpSession session=request.getSession();
		User user2=(User) session.getAttribute("user");
		System.out.println("user id="+user2.getPass());
		System.out.println("user new id="+user.getPass());
		user.setUId(user2.getUId());
		
		int resultpassord= iprofileservice.profilechangepasswordservice(user);
		
		
		return new ModelAndView("profilemenu");
	}
	
	
	/*
	@RequestMapping(value="/pdf", method = RequestMethod.GET)
	public ModelAndView pdf(ModelAndView modelAndView) {
	   // logger.info("--------------generate PDF report----------");
	 
	    Map<String,Object> parameterMap = new HashMap<String,Object>();
	    parameterMap.put("message", "Thor");
	    //pdfReport bean has ben declared in the jasper-views.xml file
	    modelAndView = new ModelAndView("helloReport", parameterMap);
	 
	    return modelAndView;
	}*/
}
