package in.extremityindia.ibanking.apps.controllers;

import java.io.IOException;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import in.extremityindia.ibanking.apps.beans.Account;
import in.extremityindia.ibanking.apps.beans.MapAccountCustomer;
import in.extremityindia.ibanking.apps.beans.User;
import in.extremityindia.ibanking.apps.exceptions.BelowMinimumBalanceException;
import in.extremityindia.ibanking.apps.exceptions.NotEnoughtCashInBalanceException;
import in.extremityindia.ibanking.apps.exceptions.NotFoundException;
import in.extremityindia.ibanking.apps.exceptions.OverDraftLimitExceededException;
import in.extremityindia.ibanking.apps.exceptions.PinNotFoundException;
import in.extremityindia.ibanking.apps.exceptions.RoundAmountCheckException;
import in.extremityindia.ibanking.apps.helpers.ValidationHelper;
import in.extremityindia.ibanking.apps.service.ITransactionService;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class TransactionController {
    private int transactionCount = 0; 
    public int userPin;
    public int accountId=0;
    public double  oldamt;
    public int accountType;
    public int customerId=0;
	public int account_id=0;
	
		
	 
	//double TOTALAMOUNT;
	
	@Autowired
	ITransactionService iTransactionService;
	
	//***************************** Pin Check Validation*****************************
	

	@RequestMapping(value="/pincheck" ,method={ RequestMethod.GET,RequestMethod.POST } )
	public @ResponseBody String pinCheck( @RequestParam String pin,@ModelAttribute User user,HttpServletRequest request ,HttpServletResponse response) throws IOException 
	{
		
	
		String pinIn=iTransactionService.validatePin(pin);
		System.out.println("complete validatePin...");
		
		HttpSession session = request.getSession();
		User userlist=(User)session.getAttribute("user");
        Set pinUser = userlist.getCustomer().getMapAccountCustomers();
        System.out.println("set:"+pinUser);
        Iterator itr=pinUser.iterator();
  	          while(itr.hasNext())
               	{
  		        MapAccountCustomer mapacc=(MapAccountCustomer)itr.next();
  		           userPin=mapacc.getAccount().getPin();
  		           System.out.println("UserPin:"+userPin);
  	         	}
  	          
	   System.out.println("pin check......");
		if(pinIn.equals(pin))
		{
		Integer pinIN=Integer.parseInt(pinIn);
			try
			{
				System.out.println("pin check try");
			    if(pinIN==userPin)
			     {
				    System.out.println("Pin Successfully Check....");
				  
				    response.getWriter().write(" ");
			     }
			     else
			     {
				    throw new PinNotFoundException("Pin not found");
			     }
			}
			catch(Exception a)
			{
					a.printStackTrace();
					response.getWriter().write(a.getMessage());
			}
		} 
		else{
			System.out.println("pin check else..");
			response.getWriter().write(pinIn);
			
		}
        
		return null;
	}
	
	
	//********************************** Amount Validation*****************************
	
	
	@RequestMapping(value="/amountcheck" ,method={ RequestMethod.GET,RequestMethod.POST } )
	public @ResponseBody String amountCheck( @RequestParam String amount,@ModelAttribute User user,HttpServletRequest request ,HttpServletResponse response) throws IOException 
	{
		System.out.println("amount check Controller");
		System.out.println("Enter amount:"+amount);
		
        String amountCheck=iTransactionService.validateAmount(amount);
        if(amountCheck.equals(amount))
        {
		System.out.println("Amount Check Successfully...");
		  response.getWriter().write(" ");
		} 
		else{
			
			response.getWriter().write(amountCheck);
			
		}
        
		return null;
	}
	
	//****************************Amount validation for Withdraw***********************
	
	@RequestMapping(value="/amountwithdrawcheck" ,method={ RequestMethod.GET,RequestMethod.POST } )
	public @ResponseBody String amountWithdrawCheck( @RequestParam String amount,String pin,@ModelAttribute User user,HttpServletRequest request ,HttpServletResponse response) throws IOException 
	{
		System.out.println("amountwithdraw check Controller");
		System.out.println("Enter amount:"+amount);
		
		
        String amountCheck=iTransactionService.validateWithdrawAmount(amount);
        System.out.println("amountCheck"+amountCheck);
        if(amountCheck.equals(amount))
        {
		    System.out.println("AmountWithdraw Check Successfully...");
		      try
		       {
		    	  double amountcheck=Double.parseDouble(amountCheck);
		          HttpSession session = request.getSession();
		  		User userlist=(User)session.getAttribute("user");
		          Set User = userlist.getCustomer().getMapAccountCustomers();
		          System.out.println("set:"+User);
		          Iterator itr=User.iterator();
		    	          while(itr.hasNext())
		                 	{
		    		        MapAccountCustomer mapacc=(MapAccountCustomer)itr.next();
		    		           accountId=mapacc.getAccount().getAccountId();
		    		           System.out.println("UserPin:"+accountId);
		    		          
		    	         	}
		         	double  AMOUNT=iTransactionService.getTotalAmount(pin,accountId);
		       	System.out.println("TotalAmount for Withdraw"+AMOUNT);
			if( AMOUNT>amountcheck)
			      {
				System.out.println("Amount......Withdraw ...Successfully");
				   if(amountcheck%100!=0)
			           {
			     	throw new RoundAmountCheckException("Enter Amount in 100 multiple");
			            }
				   else if(amountcheck>20000)
				   {
					   throw new OverDraftLimitExceededException("You can not Withdraw Amount over RS 20000/-");
				   }
			            else
		                  	{
				        System.out.println("Amount .....done");
			                }
				response.getWriter().write(" ");
			        }
			    else
			      {
				     throw new BelowMinimumBalanceException("Mimimum Balance ....");
			      }
			 
		 }
		      catch(Exception e)
		         {
		    	  if(e instanceof BelowMinimumBalanceException )
		    	  {
		    		  e.printStackTrace();
		    		  response.getWriter().write(e.getMessage());
		    	  }
		    	  else if(e instanceof RoundAmountCheckException)
		    	  {
		    		  e.printStackTrace();
		    	      response.getWriter().write(e.getMessage());
		    	  }
		    	  else if(e instanceof OverDraftLimitExceededException)
		    	  {
		    		  e.printStackTrace();
		             response.getWriter().write(e.getMessage());
		    	  }
		    	  
			     
		          }
		} 
		else{
			
			response.getWriter().write(amountCheck);
			
		}
        
		return null;
	}
	
	//*********************************Deposite Amount***************************
	
	@RequestMapping(value="/deposite" ,method={ RequestMethod.GET,RequestMethod.POST } )
	public ModelAndView depositeAmount(@RequestParam String pin,String amount,@ModelAttribute User user,HttpServletRequest request ,HttpServletResponse response)
	{
		System.out.println("deposite controller.....");
		HttpSession session = request.getSession();
		User userlist=(User)session.getAttribute("user");
        Set User = userlist.getCustomer().getMapAccountCustomers();
        System.out.println("set:"+User);
        Iterator itr=User.iterator();
  	          while(itr.hasNext())
               	{
  		        MapAccountCustomer mapacc=(MapAccountCustomer)itr.next();
  		           accountId=mapacc.getAccount().getAccountId();
  		           accountType=mapacc.getAccount().getAccountType();
  		           customerId=mapacc.getCustomer().getCustomerId();
  		         
  		           System.out.println("UserPin:"+accountId);
  		           System.out.println("oldamount"+oldamt);
  	         	}
		Double TOTALAMOUNT=iTransactionService.depositeAmount(pin, amount,accountId, customerId);
		System.out.println("deposite amount successfully....");
		System.out.println("Total Amount...."+TOTALAMOUNT);
		
		return new ModelAndView("payment_transfermenu");
		
	}
	
	
	//***********************************Withdraw Amount*********************************
	
	
	@RequestMapping(value="/withdraw" ,method={ RequestMethod.GET,RequestMethod.POST } )
	public   ModelAndView withdrawAmount(@RequestParam String pin,String amount,@ModelAttribute User user,HttpServletRequest request ,HttpServletResponse response) throws IOException
			{
		
		System.out.println("controller withdraw");
		
		HttpSession session = request.getSession();
		User userlist=(User)session.getAttribute("user");
        Set User = userlist.getCustomer().getMapAccountCustomers();
        System.out.println("set:"+User);
        Iterator itr=User.iterator();
  	          while(itr.hasNext())
               	{
  		        MapAccountCustomer mapacc=(MapAccountCustomer)itr.next();
  		           accountId=mapacc.getAccount().getAccountId();
  		           accountType=mapacc.getAccount().getAccountType();
  		           customerId=mapacc.getCustomer().getCustomerId();
  		        
  		           System.out.println("UserPin:"+accountId);
  		           System.out.println("oldamount"+oldamt);
  	         	}
  	          
  	              List<String> transactionList= iTransactionService.getTransactionCount(accountId);
  	             int noRows=transactionList.size();
  	             System.out.println("no of rows:"+noRows);
  	             if(noRows<=5)
  	             {
		              iTransactionService.withdrawAmount(pin,amount, accountId,customerId);
		              System.out.println("Transaction can Completed...");
  	             }
		       else
		         {
		    	  String msg="Your 5 Transaction can Completed...";
		    	  System.out.println("Your 5 Transaction can Completed...controller");
		    	   return new ModelAndView("payment_transfermenu","msg",msg);
			   
		             }
  	         return new ModelAndView("payment_transfermenu");
		
	}

	//***********************************Fund transfer Code*********************************
	@RequestMapping(value="/transaction",method={RequestMethod.POST,RequestMethod.GET})
	public @ResponseBody String account(HttpServletRequest request,HttpServletResponse response
			,@ModelAttribute User user) throws IOException
	{
		System.out.println("In FundTransfer Controller.........");
	
		
		HttpSession session= request.getSession();
		User userdata=(User)session.getAttribute("user");
		Set setamount=userdata.getCustomer().getMapAccountCustomers();
		Iterator amount1= setamount.iterator();
		double useramount=0;
		while(amount1.hasNext())
		{
			MapAccountCustomer mapAccountCustomer =(MapAccountCustomer) amount1.next();
			useramount=mapAccountCustomer.getAccount().getAmount();
			accountId=mapAccountCustomer.getAccount().getAccountId();
			customerId=mapAccountCustomer.getCustomer().getCustomerId();
			userPin=mapAccountCustomer.getAccount().getPin();
			System.out.println("userPin----------"+userPin);
		}
		
		String amount=request.getParameter("amount");
		System.out.println("String amount"+amount);
		double transactionAmount=Double.parseDouble(amount);
		System.out.println("DOUBLE AMOUNT"+transactionAmount);
		
		String beneficiary_name   = request.getParameter("beneficiary_name");
		System.out.println("beneficiary_name"+beneficiary_name);
		
		String beneficiary_accno  = request.getParameter("beneficiary_accountno");
		int accountIdTo=Integer.parseInt(beneficiary_accno);
		
		String ifsc_code=request.getParameter("ifsc_code");
		String getpin=request.getParameter("pin");
		int pin=Integer.parseInt(getpin);
		System.out.println("Pin---------------------------"+pin);		
		
		List<Account> accountdata=iTransactionService.getAccountId();
		
		String acc=ValidationHelper.isValidAccountId(accountdata,beneficiary_accno);
		
		if(acc.equals(beneficiary_accno))
		{
			MapAccountCustomer map=iTransactionService.getAccountdata(accountIdTo);
				String fname=map.getCustomer().getFname();
				String lname=map.getCustomer().getLname();
				System.out.println(fname);
				System.out.println(lname);
				String name=fname.concat(lname);
				System.out.println("name---------------"+name);
				try
				{
					System.out.println("before1111111111111111111111111");
					if((useramount<transactionAmount))
					{
						System.out.println("iN nOT eNOUGH"+useramount+"  "+transactionAmount);
						throw new NotEnoughtCashInBalanceException("You do not hava sufficent balance");
					}
					System.out.println("before--------------------------------");
					if(!(userPin==pin))
					{
						System.out.println("!(userPin==pin)-------------------"+pin);
						throw new PinNotFoundException("Pin No is incorrect");
					}
					if(!(transactionAmount>1))
					{
						throw new NotEnoughtCashInBalanceException("Amount Greater than One");
					}
					if(!(name.equals(beneficiary_name)))
					{
						throw new NotFoundException("Beneficiary name is incorrect");
							
					}
					if(!(map.getAccount().getBankBranch().getIfsc()).equals(ifsc_code))
					{
						throw new NotFoundException("IFSC Code not match");
						
					}
					iTransactionService.fundtransfer(customerId,accountId,accountIdTo,transactionAmount,useramount);
					response.getWriter().write("Amount transfered Successfully");
				}
				catch(NotFoundException e)
				{
					response.getWriter().write(e.getMessage());
					
				}
				catch(NotEnoughtCashInBalanceException e)
				{
					System.out.println("In Catch block");
					response.getWriter().write(e.getMessage());
				}
				catch(PinNotFoundException e)
				{
					response.getWriter().write(e.getMessage());
				}
		}
		else
		{
			response.getWriter().write("Account Number Is Incorrect.");
		}

		return null;
  }
}
 