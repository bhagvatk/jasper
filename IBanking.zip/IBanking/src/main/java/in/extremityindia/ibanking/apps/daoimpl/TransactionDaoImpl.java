package in.extremityindia.ibanking.apps.daoimpl;



import java.sql.Time;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.criterion.Criterion;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;

import in.extremityindia.ibanking.apps.beans.*;
import in.extremityindia.ibanking.apps.dao.ITransactionDao;

public class TransactionDaoImpl implements ITransactionDao{

	@Autowired
	private SessionFactory hibernateSessionFactory;

	public void setSessionFactory(SessionFactory sf) {
		this.hibernateSessionFactory = sf;
	}
	
	Date date = new Date();
	
    String strDateFormat = "dd:MM:yyyy";
    String strDateFormat1 = "hh:mm:s a";
    DateFormat dateFormat = new SimpleDateFormat(strDateFormat);
    DateFormat dateFormattime = new SimpleDateFormat(strDateFormat1);
    String transactionDate= dateFormat.format(date);
    String transactionTime= dateFormattime.format(date);

	@Override
	public Double depositeAmount(String pin, String amount,int accountId,int customerId) {
		
	
		int account_id_to=0;
		String transaction_type="DEPOSITE";
		String  transaction_time="18-01-2016";
		
		Account account=new Account();
		Session session = hibernateSessionFactory.openSession();
		 Account acount=(Account) session.load(Account.class, accountId);
		double AMOUNT =acount.getAmount();
		
		System.out.println("old Amount:"+ AMOUNT);
		Integer pinIn=Integer.parseInt(pin);
		account.setPin(pinIn);
		Double amt=Double.parseDouble(amount);
		 double totalAmount=AMOUNT+amt;
		account.setAmount(totalAmount);

		account.setAccountId(accountId);
		
		
      	System.out.println("deposite dao....");
      	
      Transaction transaction=session.beginTransaction();
      	 Account accountresult=(Account)session.merge(account);
      	 transaction.commit();
      	double TOTALAMOUNT=accountresult.getAmount();
      	 
      	 System.out.println("totalAmount Result dao:"+TOTALAMOUNT);
      	 
      	 //********************* insert Deposite Information into Transation Table *******************
		    SQLQuery queryTx=  session.createSQLQuery("insert into transaction (customer_id_by,account_id,account_id_to,transaction_type,transaction_amount,transaction_date,transaction_time)values('"+customerId+"','"+ accountId+"','"+account_id_to+"','"+transaction_type +"','"+amount+"','"+transactionDate+"','"+transactionTime+"')");
		    queryTx.executeUpdate();
		    System.out.println("Transation Table inserted successfully......");
     	
		return TOTALAMOUNT;
	}

	@Override
	public Double gettotalAmount(String pin, int accountId) {
	
		Session session = hibernateSessionFactory.openSession();
        Account account=(Account) session.get(Account.class, accountId);
       Double taotalAmountWithdraw =account.getAmount();
       System.out.println("TotalAmount Dao:"+taotalAmountWithdraw);
       return taotalAmountWithdraw;
	}
	
	//***************************Transcation count*******************
	
	@Override
	public List<String> getTransactionCount(int accountid) {
	
		Session session = hibernateSessionFactory.openSession();
		
		Query query=session.createSQLQuery("select t.transaction_time from transaction t where t.account_id="+accountid+" and t.transaction_time='"+transactionTime+"'");
		//Query query=session.createQuery("select t.transactionTime from Transaction t where t.account="+accountid+"t.transactionTime="+currentDate);
	    List<String> transactionList=query.list();
		     for(String s:transactionList){
		    	 System.out.println("Transaction date and Time:"+s);
		     }
		     return transactionList;
		                
		     
	}

	//******************************Withdraw Amount*********************
	@Override
	public void withdrawAmount(String pin, String amount,int accountId ,int customerId) {
		int account_id_to=0;
		String transaction_type="WITHDRAW";
		
	
		Session session = hibernateSessionFactory.openSession();
		 Account acount=(Account) session.load(Account.class, accountId);
			double AMOUNT =acount.getAmount();
			System.out.println("old Amount:"+ AMOUNT);
			
			Double amt=Double.parseDouble(amount);
			
			 double totalAmount=AMOUNT-amt;
			 System.out.println("After withdraw Amount:"+ totalAmount);
			 
			//******************** Update Withdraw Amount************************
			 
			SQLQuery query=  session.createSQLQuery("Update account a set a.amount="+totalAmount+"where a.account_id="+accountId);
		    query.executeUpdate();
		    System.out.println("updated successfully...");
		    
		    //********************* insert Withdraw Information into Transation Table *******************
		    SQLQuery queryTx=  session.createSQLQuery("insert into transaction (customer_id_by,account_id,account_id_to,transaction_type,transaction_amount,transaction_time,transaction_date)values('"+customerId+"','"+ accountId+"','"+account_id_to+"','"+transaction_type +"','"+amount+"','"+transactionTime+"','"+transactionDate+"')");
		    queryTx.executeUpdate();
		    System.out.println("Transation Table inserted successfully......");
		
	}

	@Override
	public List<Account> getAccountId()
	{
		Session session=hibernateSessionFactory.openSession();
		List<Account> resList=session.createCriteria(Account.class).list();			
		System.out.println("In Dao getAccountId()"+resList);
		return resList;
	}

	/**********************Fund Transfer Methods**************************/
	
	
	
	@Override
	public MapAccountCustomer getAccountdata(int account_id) 
	{
		System.out.println("In Dao-----------------------------------------"+account_id);
		Session session=hibernateSessionFactory.openSession();
		
		String sql="select m.map_id from map_account_customer m where m.account_id="+account_id;
		Query query=session.createSQLQuery(sql);
		List map_id1=query.list();
		int map_id=0;
		Iterator iterator=map_id1.iterator();
		while(iterator.hasNext())
		{
			map_id=(int) iterator.next();
		}
		MapAccountCustomer mapAccountCustomers= (MapAccountCustomer)session.load(MapAccountCustomer.class,map_id);
		System.out.println(" In Dao" +mapAccountCustomers);
		return mapAccountCustomers;
	}
	
	public void fundtransfer(int customerId,int accountId,int accountIdTo,double transactionAmount,double useramount)
	{
		String transactionType="TRANSFER";
		Session session= hibernateSessionFactory.openSession();
		//Code to insert data into transaction table......
		String sql="insert into transaction(customer_id_by,account_id,account_id_to,transaction_type,transaction_amount,transaction_date,transaction_time)values('"+customerId+"','"+accountId+"','"+accountIdTo+"','"+transactionType+"','"+transactionAmount+"','"+transactionDate+"','"+transactionTime+"')";
		Query query=session.createSQLQuery(sql);
		int result = query.executeUpdate();
		
		
		System.out.println("Date-----"+date);
		
		//code to Diduct balance from user account
		double money=useramount-transactionAmount;
		String sql1="update account a set amount=? where a.account_id="+accountId;
		Query query1=session.createSQLQuery(sql1);
		query1.setParameter(0,money);
		int result1=query1.executeUpdate();
		
		//Code to Deposite balance in user account
		Account account=(Account)session.load(Account.class,accountIdTo);
		double money2=account.getAmount();
		double money3=transactionAmount+money2;
		String sql2="update account a set amount=? where a.account_id="+accountIdTo;
		Query query2=session.createSQLQuery(sql2);
		query2.setParameter(0,money3);
		int result2=query2.executeUpdate();
	}



}
