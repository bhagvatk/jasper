package in.extremityindia.ibanking.apps.dao;

import java.util.List;


import in.extremityindia.ibanking.apps.beans.Customer;
import in.extremityindia.ibanking.apps.beans.User;

public interface IProfileDao {
public abstract int profileupadate(Customer customer);
public int profilechangepassword(User user);
}
