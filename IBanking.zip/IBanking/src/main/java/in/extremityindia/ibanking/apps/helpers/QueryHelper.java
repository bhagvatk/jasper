package in.extremityindia.ibanking.apps.helpers;

import java.util.List;

import org.hibernate.SessionFactory;
import org.hibernate.classic.Session;
import org.springframework.beans.factory.annotation.Autowired;

public class QueryHelper {

	@Autowired
	private SessionFactory hibernateSessionFactory;

	public SessionFactory getHibernateSessionFactory() {
		return hibernateSessionFactory;
	}

	public void setHibernateSessionFactory(SessionFactory hibernateSessionFactory) {
		this.hibernateSessionFactory = hibernateSessionFactory;
	}

	@SuppressWarnings("unchecked")
	public  List<Object> getRecords(Object object) {
		List<Object> objectList = null;
		String className = object.getClass().getSimpleName();
		Session session = hibernateSessionFactory.openSession();
		org.hibernate.Query query = session.createQuery("from " + className);
		objectList = query.list();
		return objectList;
	}
}
