package in.extremityindia.ibanking.apps.helpers;

import in.extremityindia.ibanking.apps.beans.Account;
import in.extremityindia.ibanking.apps.servicebusiness.AccountBusiness;

import java.util.Random;

import org.springframework.beans.factory.annotation.Autowired;
public class AccountCreationHelper {

	/*Author TANVEER BOBADE*/
	@Autowired
	 AccountBusiness accountBusiness;
	
	public static long ACCOUNT_NUMBER=1000000000;
	public int RANDOM_INTEGER;
	public static int COUNT=1;
	public static int PIN_NUMBER1;
	public static int PIN_NUMBER2;
	//public static int LAST_ACCOUNT_NUMBER;
	
		public static long accountNumber(long LAST_ACCOUNT_NUMBER)
		{
			System.out.println("Last Account Number   "+LAST_ACCOUNT_NUMBER);
			
			if(LAST_ACCOUNT_NUMBER==0)
			{
			System.out.println(LAST_ACCOUNT_NUMBER);
			ACCOUNT_NUMBER=LAST_ACCOUNT_NUMBER;
			System.out.println(ACCOUNT_NUMBER);
			
			}
			else
			{
				LAST_ACCOUNT_NUMBER++;
				System.out.println("lAST ACCOUNT NUMBER"+LAST_ACCOUNT_NUMBER);
				ACCOUNT_NUMBER=LAST_ACCOUNT_NUMBER;
				System.out.println("ACCOUNT NO GENERATED");
			}
			return ACCOUNT_NUMBER;
		}
		
		
			public static int generatePin() throws Exception {
			Random generator = new Random();
			generator.setSeed(System.currentTimeMillis());
			PIN_NUMBER1 = generator.nextInt(999)+999;
			PIN_NUMBER2=generator.nextInt(555)+1000;
			
			
			if(COUNT==0)
			{
				COUNT++;
			
				return PIN_NUMBER1;
				
			}
			else
				{
				
				COUNT--;
				return PIN_NUMBER2;
				}
			
			}

	
	
	
}
