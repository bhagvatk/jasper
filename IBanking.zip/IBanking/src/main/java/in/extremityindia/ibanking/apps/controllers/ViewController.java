package in.extremityindia.ibanking.apps.controllers;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;


@Controller
public class ViewController {

	
	@RequestMapping(value = "getStates", method = { RequestMethod.GET,
			RequestMethod.POST })
	@GET @Path("/") @Produces(MediaType.APPLICATION_JSON)
	public @ResponseBody String getStates()
	{
		System.out.println("in view controller");
		return null;
	}
	
	
}
