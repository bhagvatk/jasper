package in.extremityindia.ibanking.apps.exceptions;

public class NoPermissionException extends TransactionAbortedException {
	/**
	 * @author Rahul Moundekar
	 */
	private static final long serialVersionUID = 1L;

	public NoPermissionException(String msg) {
		super(msg);
	}

}
