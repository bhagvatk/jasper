package in.extremityindia.ibanking.apps.exceptions;

public class NotEnoughtCashInBalanceException extends
		TransactionAbortedException {
	/**
	 * @author Rahul Moundekar
	 */
	private static final long serialVersionUID = 1L;

	public NotEnoughtCashInBalanceException(String msg) {
		super(msg);
	}
}
