package in.extremityindia.ibanking.apps.daoimpl;

import java.util.Iterator;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Projections;
import org.springframework.beans.factory.annotation.Autowired;

import in.extremityindia.ibanking.apps.beans.Account;
import in.extremityindia.ibanking.apps.beans.BankBranch;
import in.extremityindia.ibanking.apps.dao.IBranchDao;

public class BranchDaoImpl implements IBranchDao {

	public static int IFSC_INTEGER_CODE;
	public static String REGISTERED_ACCOUNT_LOCATION;
	public static String REGISTERED_ACCOUNT_STATE;
	public static String REGISTERED_ACCOUNT_CITY;
	public static String REGISTERED_ACCOUNT_IFSC;
	
	
	@Autowired
	private SessionFactory hibernateSessionFactory;

	public void setSessionFactory(SessionFactory sf) {
		this.hibernateSessionFactory = sf;
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<BankBranch> getBranchList() {
		List<BankBranch> branchs = null;
		try {
			Session session = hibernateSessionFactory.openSession();
			branchs=session.getNamedQuery("BankBranch.findAll").list();
			System.err.println("branch list : " + branchs);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return branchs;
	}

	@Override
	public void insertBranches(BankBranch bankBranch) {
		Session session = hibernateSessionFactory.openSession();

		session.saveOrUpdate(bankBranch);
	}

	@Override
	public int checkIFSC() {
	
		System.out.println("In dao ChecK IFSC ************************************************");
			Session session=hibernateSessionFactory.openSession();
			Query query;
			try{
				System.out.println("In Tryyyyyyyyyyyyyyyyyyyyyyyyy");
			 query=session.createQuery("select b.ifsc from BankBranch b");
				Iterator itr=query.list().iterator();
				while(itr.hasNext())
				{
					
					String IFSCCode=(String)itr.next();
					String S=IFSCCode.substring(3,11);
					System.out.println(S);
					int IFSC_INTEGER_CODE_GOT =Integer.parseInt(S);
					IFSC_INTEGER_CODE=IFSC_INTEGER_CODE_GOT;
					System.out.println("7777777777  "+IFSC_INTEGER_CODE_GOT);
					if(IFSC_INTEGER_CODE_GOT>IFSC_INTEGER_CODE)
					{
						System.out.println("condition");
						IFSC_INTEGER_CODE_GOT=IFSC_INTEGER_CODE;
					}
				}
			}
			catch(Exception e)
			{
				IFSC_INTEGER_CODE=0;	
			}
		
				System.out.println("Check IFSc");
			
					
					System.out.println("Maximum value"+IFSC_INTEGER_CODE);
				
			return IFSC_INTEGER_CODE;
				
			}
			
		}
		


